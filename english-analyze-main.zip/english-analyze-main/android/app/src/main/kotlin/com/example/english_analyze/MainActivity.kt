package com.example.english_analyze

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
