// API Configuration
// This file contains API keys and configuration settings
// IMPORTANT: Replace these with your actual API keys before using

class ApiConfig {
  // Google Gemini API Key
  // Get your API key from: https://makersuite.google.com/app/apikey
  static const String geminiApiKey = 'YOUR_GEMINI_API_KEY_HERE';

  // Supabase Configuration (already set in main.dart)
  static const String supabaseUrl = 'url';
  static const String supabaseAnonKey = 'api';

  // API Settings
  static const int geminiTimeoutSeconds = 30;
  static const int maxRetryAttempts = 3;

  // Feature flags
  static const bool enableGeminiAnalysis = true;
  static const bool enableAdvancedFeatures = true;

  // Validation
  static bool get isGeminiConfigured =>
      geminiApiKey != 'YOUR_GEMINI_API_KEY_HERE' && geminiApiKey.isNotEmpty;
}
