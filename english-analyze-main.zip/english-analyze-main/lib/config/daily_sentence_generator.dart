import 'dart:convert';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'api_config.dart';

class DailySentenceGenerator {
  static GenerativeModel? _geminiModel;
  static DateTime? _lastGenerationDate;
  static List<String> _cachedSentences = [];

  // Initialize Gemini model
  static void _initializeGemini() {
    if (ApiConfig.isGeminiConfigured && _geminiModel == null) {
      _geminiModel = GenerativeModel(
        model: 'gemini-pro',
        apiKey: ApiConfig.geminiApiKey,
      );
    }
  }

  // Get daily sentences - generates new ones each day
  static Future<List<String>> getDailySentences() async {
    final today = DateTime.now();
    final todayDateOnly = DateTime(today.year, today.month, today.day);

    // Check if we already have sentences for today
    if (_lastGenerationDate != null &&
        _lastGenerationDate!.isAtSameMomentAs(todayDateOnly) &&
        _cachedSentences.isNotEmpty) {
      return _cachedSentences;
    }

    // Try to get from database first
    final storedSentences = await _getSentencesFromDatabase(todayDateOnly);
    if (storedSentences.isNotEmpty) {
      _cachedSentences = storedSentences;
      _lastGenerationDate = todayDateOnly;
      return _cachedSentences;
    }

    // Generate new sentences with AI
    final newSentences = await _generateNewSentences();
    if (newSentences.isNotEmpty) {
      // Save to database for future use
      await _saveSentencesToDatabase(newSentences, todayDateOnly);
      _cachedSentences = newSentences;
      _lastGenerationDate = todayDateOnly;
      return _cachedSentences;
    }

    // Fallback to default sentences if AI fails
    return getDefaultSentences();
  }

  // Generate new sentences using AI
  static Future<List<String>> _generateNewSentences() async {
    try {
      _initializeGemini();

      if (_geminiModel == null) {
        print('Gemini not configured, using default sentences');
        return [];
      }

      final prompt = '''
Generate 15 practice sentences for English pronunciation training. 
Each sentence should:
1. Focus on different pronunciation challenges (consonant clusters, vowel sounds, stress patterns)
2. Be suitable for intermediate English learners
3. Include a variety of sounds: th, r, l, ch, sh, ng, difficult vowel combinations
4. Range from simple to moderately complex
5. Be practical and meaningful (not tongue twisters)
6. Include different sentence types (statements, questions, exclamations)

Examples of good sentences:
- "The weather forecast shows rain throughout the week."
- "Can you recommend a restaurant with vegetarian options?"
- "She thoroughly enjoyed the chocolate cake at the celebration."

Please provide exactly 15 sentences in JSON format:
{
  "sentences": [
    "sentence 1",
    "sentence 2",
    ...
  ]
}

Focus on natural, conversational sentences that help with real-world communication.
''';

      final content = [Content.text(prompt)];
      final response = await _geminiModel!
          .generateContent(content)
          .timeout(Duration(seconds: ApiConfig.geminiTimeoutSeconds));

      if (response.text != null) {
        // Extract JSON from response
        final jsonText = response.text!;
        final jsonStart = jsonText.indexOf('{');
        final jsonEnd = jsonText.lastIndexOf('}') + 1;

        if (jsonStart != -1 && jsonEnd > jsonStart) {
          final jsonString = jsonText.substring(jsonStart, jsonEnd);
          final jsonData = jsonDecode(jsonString) as Map<String, dynamic>;

          if (jsonData['sentences'] is List) {
            final sentences = (jsonData['sentences'] as List)
                .map((s) => s.toString())
                .where((s) => s.isNotEmpty && s.length > 10 && s.length < 200)
                .toList();

            if (sentences.length >= 10) {
              print('Generated ${sentences.length} new sentences with AI');
              return sentences;
            }
          }
        }
      }
    } catch (e) {
      print('Error generating AI sentences: $e');
    }

    return [];
  }

  // Get sentences from database
  static Future<List<String>> _getSentencesFromDatabase(DateTime date) async {
    try {
      final client = Supabase.instance.client;
      final dateString = date.toIso8601String().split(
        'T',
      )[0]; // YYYY-MM-DD format

      final response = await client
          .from('daily_sentences')
          .select('sentences')
          .eq('date', dateString)
          .limit(1);

      if (response.isNotEmpty) {
        final sentencesJson = response[0]['sentences'];
        if (sentencesJson is String) {
          final List<dynamic> sentences = jsonDecode(sentencesJson);
          return sentences.map((s) => s.toString()).toList();
        }
      }
    } catch (e) {
      print('Error getting sentences from database: $e');
    }

    return [];
  }

  // Save sentences to database
  static Future<void> _saveSentencesToDatabase(
    List<String> sentences,
    DateTime date,
  ) async {
    try {
      final client = Supabase.instance.client;
      final dateString = date.toIso8601String().split(
        'T',
      )[0]; // YYYY-MM-DD format

      await client.from('daily_sentences').upsert({
        'date': dateString,
        'sentences': jsonEncode(sentences),
        'generated_at': DateTime.now().toIso8601String(),
      });

      print('Saved ${sentences.length} sentences to database for $dateString');
    } catch (e) {
      print('Error saving sentences to database: $e');
    }
  }

  // Default fallback sentences
  static List<String> getDefaultSentences() {
    return [
      'The weather is beautiful today.',
      'Can you help me with this problem?',
      'She enjoys reading books in the library.',
      'The restaurant serves delicious food.',
      'They are planning a trip to the mountains.',
      'I need to finish my homework tonight.',
      'The children are playing in the garden.',
      'We should arrive at the airport early.',
      'The meeting will start at three o\'clock.',
      'He works as a software engineer.',
      'The movie was extremely entertaining.',
      'She speaks three languages fluently.',
      'The store closes at nine in the evening.',
      'They celebrated their anniversary yesterday.',
      'The project deadline is next Friday.',
    ];
  }

  // Get sentences by difficulty level
  static Future<List<String>> getSentencesByDifficulty(
    String difficulty,
  ) async {
    final allSentences = await getDailySentences();

    switch (difficulty.toLowerCase()) {
      case 'easy':
        return allSentences.take(5).toList();
      case 'medium':
        return allSentences.skip(5).take(5).toList();
      case 'hard':
        return allSentences.skip(10).toList();
      default:
        return allSentences;
    }
  }

  // Clear cache to force regeneration (for testing)
  static void clearCache() {
    _cachedSentences.clear();
    _lastGenerationDate = null;
  }
}
