/// Application Configuration
/// Centralized configuration for the English Pronunciation Analyzer app
///
/// This file contains all API keys, settings, and configuration values.
/// IMPORTANT: Replace placeholder values with actual credentials before deployment.

class AppConfig {
  // ================================
  // APP INFORMATION
  // ================================
  static const String appName = 'English Pronunciation Analyzer';
  static const String appVersion = '1.0.0';
  static const String appDescription =
      'AI-powered pronunciation analysis and feedback';

  // ================================
  // SUPABASE CONFIGURATION
  // ================================
  static const String supabaseUrl = 'https://gjjsmozcsdvcjodgdhlk.supabase.co';
  static const String supabaseAnonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdqanNtb3pjc2R2Y2pvZGdkaGxrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTczNTAyMDUsImV4cCI6MjA3MjkyNjIwNX0.abP2xoW-78v7Sn_fZCJ5lK3_cgPPiWg-dqQrHe43sHc';

  // ================================
  // GOOGLE GEMINI AI CONFIGURATION
  // ================================
  /// Get your API key from: https://makersuite.google.com/app/apikey
  static const String geminiApiKey = 'AIzaSyCIP4BcybsEoBC50VjImG3_JftQaDPhBeE';

  /// Gemini model preferences (in order of preference)
  static const List<String> geminiModels = [
    'gemini-1.5-flash',
    'gemini-1.5-pro',
    'gemini-pro',
  ];

  static const int geminiTimeoutSeconds = 30;
  static const int geminiMaxRetryAttempts = 3;

  // ================================
  // AUDIO RECORDING SETTINGS
  // ================================
  static const int maxRecordingDurationSeconds = 30;
  static const int minRecordingDurationSeconds = 1;
  static const int audioSampleRate = 44100;
  static const int audioBitRate = 128000;
  static const int minAudioFileSizeBytes = 1000; // 1KB minimum

  // ================================
  // UI/UX SETTINGS
  // ================================
  static const Duration pageTransitionDuration = Duration(milliseconds: 400);
  static const Duration loadingDialogMinimumDuration = Duration(
    milliseconds: 500,
  );

  // Pronunciation score thresholds
  static const double excellentScoreThreshold = 80.0;
  static const double goodScoreThreshold = 60.0;
  static const double fairScoreThreshold = 40.0;

  // ================================
  // FEATURE FLAGS
  // ================================
  static const bool enableGeminiAnalysis = true;
  static const bool enableAdvancedFeatures = true;
  static const bool enableDebugLogging = true;
  static const bool enableAnalyticsTracking = false;

  // ================================
  // VALIDATION HELPERS
  // ================================
  /// Check if Supabase is properly configured
  static bool get isSupabaseConfigured =>
      supabaseUrl.isNotEmpty &&
      supabaseAnonKey.isNotEmpty &&
      !supabaseUrl.contains('YOUR_') &&
      !supabaseAnonKey.contains('YOUR_');

  /// Check if Gemini AI is properly configured
  static bool get isGeminiConfigured =>
      geminiApiKey.isNotEmpty &&
      !geminiApiKey.contains('YOUR_') &&
      geminiApiKey.startsWith('AIza'); // Gemini keys start with "AIza"

  /// Check if all required services are configured
  static bool get isFullyConfigured =>
      isSupabaseConfigured && isGeminiConfigured;

  // ================================
  // DEFAULT CONTENT
  // ================================
  /// Default practice paragraphs when server is unavailable
  static const List<String> defaultParagraphs = [
    'The quick brown fox jumps over the lazy dog. This sentence contains every letter of the English alphabet and is perfect for pronunciation practice.',
    'Technology has revolutionized the way we communicate and learn. From smartphones to artificial intelligence, these innovations continue to shape our daily lives.',
    'Reading books regularly improves vocabulary, comprehension, and critical thinking skills. It also provides relaxation and entertainment for people of all ages.',
    'Climate change represents one of the most significant challenges of our time. Understanding its effects and taking action is crucial for future generations.',
    'Learning a new language opens doors to different cultures and opportunities. Practice, patience, and persistence are key to achieving fluency.',
  ];

  /// Default practice sentences
  static const List<String> defaultSentences = [
    'Hello, how are you today?',
    'The weather is beautiful this morning.',
    'I enjoy reading books in my free time.',
    'Technology makes our lives easier.',
    'Practice makes perfect in pronunciation.',
    'Communication is the key to success.',
    'Learning English is an exciting journey.',
    'Confidence comes with consistent practice.',
  ];

  // ================================
  // ERROR MESSAGES
  // ================================
  static const String configurationErrorTitle = 'Configuration Required';
  static const String geminiNotConfiguredMessage =
      'Gemini AI is not configured. Please set up your API key in the configuration.';
  static const String supabaseNotConfiguredMessage =
      'Supabase is not configured. Please set up your database connection.';
  static const String networkErrorMessage =
      'Network connection failed. Please check your internet connection.';
  static const String recordingPermissionErrorMessage =
      'Microphone permission is required for speech recording.';
  static const String recordingTooShortMessage =
      'Recording too short. Please speak for at least 2 seconds.';
  static const String transcriptionFailedMessage =
      'Could not understand your speech. Please try speaking more clearly.';
  static const String analysisFailedMessage =
      'Speech analysis failed. Please try again.';

  // ================================
  // SUCCESS MESSAGES
  // ================================
  static const String recordingSuccessMessage =
      'Recording completed successfully!';
  static const String analysisSuccessMessage =
      'Pronunciation analysis complete!';
  static const String transcriptionSuccessMessage =
      'Speech transcribed successfully!';

  // ================================
  // THEME COLORS
  // ================================
  static const int primaryColorValue = 0xFF7C4DFF;
  static const int secondaryColorValue = 0xFF03DAC6;
  static const int surfaceColorValue = 0xFFFFFFFF;
  static const int backgroundColorValue = 0xFFF8F9FA;
  static const int errorColorValue = 0xFFB00020;
  static const int successColorValue = 0xFF4CAF50;
  static const int warningColorValue = 0xFFFF9800;

  // ================================
  // UTILITY METHODS
  // ================================
  /// Get configuration status as a human-readable string
  static String getConfigurationStatus() {
    final buffer = StringBuffer();
    buffer.writeln('Configuration Status:');
    buffer.writeln(
      '- Supabase: ${isSupabaseConfigured ? "✓ Configured" : "✗ Missing"}',
    );
    buffer.writeln(
      '- Gemini AI: ${isGeminiConfigured ? "✓ Configured" : "✗ Missing"}',
    );
    buffer.writeln(
      '- Overall: ${isFullyConfigured ? "✓ Ready" : "✗ Needs Setup"}',
    );
    return buffer.toString();
  }

  /// Get a map of all configuration values (excluding sensitive data)
  static Map<String, dynamic> getConfigurationSummary() {
    return {
      'appName': appName,
      'appVersion': appVersion,
      'supabaseConfigured': isSupabaseConfigured,
      'geminiConfigured': isGeminiConfigured,
      'fullyConfigured': isFullyConfigured,
      'enabledFeatures': {
        'geminiAnalysis': enableGeminiAnalysis,
        'advancedFeatures': enableAdvancedFeatures,
        'debugLogging': enableDebugLogging,
        'analyticsTracking': enableAnalyticsTracking,
      },
      'audioSettings': {
        'maxDuration': maxRecordingDurationSeconds,
        'minDuration': minRecordingDurationSeconds,
        'sampleRate': audioSampleRate,
        'bitRate': audioBitRate,
      },
      'scoreThresholds': {
        'excellent': excellentScoreThreshold,
        'good': goodScoreThreshold,
        'fair': fairScoreThreshold,
      },
    };
  }
}

/// Legacy ApiConfig class for backward compatibility
/// Use AppConfig instead for new code
@Deprecated('Use AppConfig instead')
class ApiConfig {
  static String get geminiApiKey => AppConfig.geminiApiKey;
  static String get supabaseUrl => AppConfig.supabaseUrl;
  static String get supabaseAnonKey => AppConfig.supabaseAnonKey;
  static bool get isGeminiConfigured => AppConfig.isGeminiConfigured;
  static bool get isSupabaseConfigured => AppConfig.isSupabaseConfigured;
}
