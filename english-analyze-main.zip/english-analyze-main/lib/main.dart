import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/signup_screen.dart';
import 'screens/profile/leaderboard_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/profile/profile_screen.dart';
import 'screens/practice/analyzer_screen.dart';
import 'screens/practice/paragraph_practice_screen.dart';
import 'screens/practice/speech_analyzer_screen.dart';
import 'config/app_config.dart';
import 'utils/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Permission.microphone.request();
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    anonKey: AppConfig.supabaseAnonKey,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.appName,
      theme: AppTheme.lightTheme,
      initialRoute: '/login',
      onGenerateRoute: (settings) {
        Widget page;
        switch (settings.name) {
          case '/login':
            page = const LoginPage();
            break;
          case '/signup':
            page = const SignupPage();
            break;
          case '/home':
            page = const HomePage();
            break;
          case '/leaderboard':
            page = const LeaderboardPage();
            break;
          case '/analyzer':
            page = const AnalyzerPage();
            break;
          case '/paragraph':
            page = const ParagraphPracticePage();
            break;
          case '/speech-analyzer':
            page = const SpeechAnalyzer();
            break;
          case '/profile':
            page = const ProfileScreen();
            break;
          default:
            page = const LoginPage();
        }

        return PageRouteBuilder(
          settings: settings,
          pageBuilder: (context, animation, secondaryAnimation) => page,
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            const begin = Offset(1.0, 0.0);
            const end = Offset.zero;
            const curve = Curves.easeInOutCubic;

            var tween = Tween(
              begin: begin,
              end: end,
            ).chain(CurveTween(curve: curve));

            return SlideTransition(
              position: animation.drive(tween),
              child: FadeTransition(opacity: animation, child: child),
            );
          },
          transitionDuration: AppConfig.pageTransitionDuration,
        );
      },
      debugShowCheckedModeBanner: false,
    );
  }
}
