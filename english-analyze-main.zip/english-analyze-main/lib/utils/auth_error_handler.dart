/// Utility functions for handling authentication errors and converting them to user-friendly messages
class AuthErrorHandler {
  /// Converts raw authentication errors into user-friendly messages
  static String getErrorMessage(dynamic error) {
    final errorString = error.toString().toLowerCase();

    // Handle common Supabase authentication errors
    if (errorString.contains('invalid login credentials') ||
        errorString.contains('invalid_credentials')) {
      return 'Invalid email or password. Please check your credentials and try again.';
    }

    if (errorString.contains('email not confirmed') ||
        errorString.contains('email_not_confirmed')) {
      return 'Please check your email and click the confirmation link before signing in.';
    }

    if (errorString.contains('user not found') ||
        errorString.contains('user_not_found')) {
      return 'No account found with this email address. Please sign up first.';
    }

    if (errorString.contains('weak password') ||
        errorString.contains('password should be at least')) {
      return 'Password is too weak. Please use at least 6 characters.';
    }

    if (errorString.contains('invalid email') ||
        errorString.contains('invalid_email')) {
      return 'Please enter a valid email address.';
    }

    if (errorString.contains('email already in use') ||
        errorString.contains('email_address_invalid') ||
        errorString.contains('user_already_exists')) {
      return 'An account with this email already exists. Please try logging in instead.';
    }

    if (errorString.contains('network') ||
        errorString.contains('connection') ||
        errorString.contains('timeout')) {
      return 'Network error. Please check your internet connection and try again.';
    }

    if (errorString.contains('rate limit') ||
        errorString.contains('too many requests')) {
      return 'Too many attempts. Please wait a moment before trying again.';
    }

    if (errorString.contains('captcha') ||
        errorString.contains('verification')) {
      return 'Verification required. Please complete the security check.';
    }

    // Default fallback for unknown errors
    return 'Something went wrong. Please try again or contact support if the problem persists.';
  }

  /// Validates email format
  static bool isValidEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  /// Validates password strength
  static String? validatePassword(String password) {
    if (password.isEmpty) {
      return 'Password is required';
    }
    if (password.length < 6) {
      return 'Password must be at least 6 characters long';
    }
    return null;
  }

  /// Validates email format
  static String? validateEmail(String email) {
    if (email.isEmpty) {
      return 'Email is required';
    }
    if (!isValidEmail(email)) {
      return 'Please enter a valid email address';
    }
    return null;
  }
}
