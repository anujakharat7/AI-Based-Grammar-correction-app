import 'package:flutter/material.dart';
import '../config/app_config.dart';

/// Application Theme Configuration
/// Provides consistent styling across the entire app
class AppTheme {
  // ================================
  // COLOR SCHEME
  // ================================
  static const Color primaryColor = Color(AppConfig.primaryColorValue);
  static const Color secondaryColor = Color(AppConfig.secondaryColorValue);
  static const Color surfaceColor = Color(AppConfig.surfaceColorValue);
  static const Color backgroundColor = Color(AppConfig.backgroundColorValue);
  static const Color errorColor = Color(AppConfig.errorColorValue);
  static const Color successColor = Color(AppConfig.successColorValue);
  static const Color warningColor = Color(AppConfig.warningColorValue);

  // Gradient colors
  static const List<Color> primaryGradient = [primaryColor, Color(0xFF5C34CC)];
  static const List<Color> successGradient = [successColor, Color(0xFF43A047)];
  static const List<Color> errorGradient = [errorColor, Color(0xFFD32F2F)];
  static const List<Color> warningGradient = [warningColor, Color(0xFFF57C00)];

  // Text colors
  static const Color textPrimary = Color(0xFF1C1C1E);
  static const Color textSecondary = Color(0xFF6B6B6B);
  static const Color textLight = Color(0xFF9E9E9E);

  // ================================
  // TYPOGRAPHY
  // ================================
  static const String fontFamily = 'Roboto';

  static const TextStyle headingLarge = TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.w800,
    color: textPrimary,
    height: 1.2,
    fontFamily: fontFamily,
  );

  static const TextStyle headingMedium = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.w700,
    color: textPrimary,
    height: 1.2,
    fontFamily: fontFamily,
  );

  static const TextStyle headingSmall = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.w600,
    color: textPrimary,
    height: 1.3,
    fontFamily: fontFamily,
  );

  static const TextStyle titleLarge = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w600,
    color: textPrimary,
    height: 1.3,
    fontFamily: fontFamily,
  );

  static const TextStyle titleMedium = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w500,
    color: textPrimary,
    height: 1.4,
    fontFamily: fontFamily,
  );

  static const TextStyle titleSmall = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w500,
    color: textPrimary,
    height: 1.4,
    fontFamily: fontFamily,
  );

  static const TextStyle bodyLarge = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w400,
    color: textPrimary,
    height: 1.5,
    fontFamily: fontFamily,
  );

  static const TextStyle bodyMedium = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w400,
    color: textPrimary,
    height: 1.5,
    fontFamily: fontFamily,
  );

  static const TextStyle bodySmall = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.w400,
    color: textSecondary,
    height: 1.5,
    fontFamily: fontFamily,
  );

  static const TextStyle caption = TextStyle(
    fontSize: 11,
    fontWeight: FontWeight.w400,
    color: textLight,
    height: 1.4,
    fontFamily: fontFamily,
  );

  // ================================
  // SPACING & SIZING
  // ================================
  static const double spacingXS = 4.0;
  static const double spacingS = 8.0;
  static const double spacingM = 16.0;
  static const double spacingL = 24.0;
  static const double spacingXL = 32.0;
  static const double spacingXXL = 48.0;

  static const double borderRadiusS = 8.0;
  static const double borderRadiusM = 12.0;
  static const double borderRadiusL = 16.0;
  static const double borderRadiusXL = 24.0;

  static const double elevationS = 2.0;
  static const double elevationM = 4.0;
  static const double elevationL = 8.0;
  static const double elevationXL = 16.0;

  // ================================
  // COMPONENT STYLES
  // ================================

  /// Standard button style
  static ButtonStyle get primaryButtonStyle => ElevatedButton.styleFrom(
    backgroundColor: primaryColor,
    foregroundColor: Colors.white,
    elevation: elevationM,
    shadowColor: primaryColor.withOpacity(0.3),
    padding: const EdgeInsets.symmetric(
      vertical: spacingM,
      horizontal: spacingL,
    ),
    minimumSize: const Size(120, 48),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(borderRadiusM),
    ),
    textStyle: titleSmall.copyWith(color: Colors.white),
  );

  /// Secondary button style
  static ButtonStyle get secondaryButtonStyle => OutlinedButton.styleFrom(
    foregroundColor: primaryColor,
    side: BorderSide(color: primaryColor, width: 2),
    padding: const EdgeInsets.symmetric(
      vertical: spacingM,
      horizontal: spacingL,
    ),
    minimumSize: const Size(120, 48),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(borderRadiusM),
    ),
    textStyle: titleSmall.copyWith(color: primaryColor),
  );

  /// Text button style
  static ButtonStyle get textButtonStyle => TextButton.styleFrom(
    foregroundColor: primaryColor,
    padding: const EdgeInsets.symmetric(
      vertical: spacingS,
      horizontal: spacingM,
    ),
    textStyle: titleSmall.copyWith(color: primaryColor),
  );

  /// Input decoration theme
  static InputDecorationTheme get inputDecorationTheme => InputDecorationTheme(
    filled: true,
    fillColor: backgroundColor,
    contentPadding: const EdgeInsets.symmetric(
      horizontal: spacingM,
      vertical: spacingM,
    ),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(borderRadiusM),
      borderSide: BorderSide(color: Colors.grey.shade300),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(borderRadiusM),
      borderSide: BorderSide(color: Colors.grey.shade300),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(borderRadiusM),
      borderSide: const BorderSide(color: primaryColor, width: 2),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(borderRadiusM),
      borderSide: const BorderSide(color: errorColor),
    ),
    focusedErrorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(borderRadiusM),
      borderSide: const BorderSide(color: errorColor, width: 2),
    ),
    labelStyle: bodyMedium.copyWith(color: textSecondary),
    hintStyle: bodyMedium.copyWith(color: textLight),
    errorStyle: bodySmall.copyWith(color: errorColor),
  );

  // ================================
  // COMPLETE THEME DATA
  // ================================
  static ThemeData get lightTheme => ThemeData(
    useMaterial3: true,
    fontFamily: fontFamily,
    scaffoldBackgroundColor: backgroundColor,

    colorScheme: const ColorScheme.light(
      primary: primaryColor,
      secondary: secondaryColor,
      surface: surfaceColor,
      background: backgroundColor,
      error: errorColor,
      onPrimary: Colors.white,
      onSecondary: Colors.black,
      onSurface: textPrimary,
      onBackground: textPrimary,
      onError: Colors.white,
    ),

    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: titleLarge,
      iconTheme: IconThemeData(color: textPrimary),
    ),

    elevatedButtonTheme: ElevatedButtonThemeData(style: primaryButtonStyle),
    outlinedButtonTheme: OutlinedButtonThemeData(style: secondaryButtonStyle),
    textButtonTheme: TextButtonThemeData(style: textButtonStyle),

    inputDecorationTheme: inputDecorationTheme,

    textTheme: const TextTheme(
      displayLarge: headingLarge,
      displayMedium: headingMedium,
      displaySmall: headingSmall,
      headlineLarge: titleLarge,
      headlineMedium: titleMedium,
      headlineSmall: titleSmall,
      titleLarge: titleLarge,
      titleMedium: titleMedium,
      titleSmall: titleSmall,
      bodyLarge: bodyLarge,
      bodyMedium: bodyMedium,
      bodySmall: bodySmall,
      labelLarge: titleSmall,
      labelMedium: bodyMedium,
      labelSmall: caption,
    ),

    cardTheme: CardThemeData(
      elevation: elevationS,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(borderRadiusM),
      ),
      margin: const EdgeInsets.all(spacingS),
    ),

    dialogTheme: DialogThemeData(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(borderRadiusL),
      ),
      elevation: elevationL,
    ),

    snackBarTheme: SnackBarThemeData(
      backgroundColor: textPrimary,
      contentTextStyle: bodyMedium.copyWith(color: Colors.white),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(borderRadiusS),
      ),
      behavior: SnackBarBehavior.floating,
    ),
  );

  // ================================
  // UTILITY METHODS
  // ================================

  /// Get color for pronunciation score
  static Color getScoreColor(double score) {
    if (score >= AppConfig.excellentScoreThreshold) {
      return successColor;
    } else if (score >= AppConfig.goodScoreThreshold) {
      return warningColor;
    } else if (score >= AppConfig.fairScoreThreshold) {
      return Colors.orange.shade700;
    } else {
      return errorColor;
    }
  }

  /// Get score label for pronunciation score
  static String getScoreLabel(double score) {
    if (score >= AppConfig.excellentScoreThreshold) {
      return 'Excellent';
    } else if (score >= AppConfig.goodScoreThreshold) {
      return 'Good';
    } else if (score >= AppConfig.fairScoreThreshold) {
      return 'Fair';
    } else {
      return 'Needs Work';
    }
  }

  /// Create a gradient container
  static Container gradientContainer({
    required Widget child,
    required List<Color> colors,
    double? borderRadius,
    EdgeInsets? padding,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: colors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(borderRadius ?? borderRadiusM),
      ),
      padding: padding,
      child: child,
    );
  }

  /// Create a shadow box decoration
  static BoxDecoration shadowDecoration({
    Color? color,
    double? borderRadius,
    double? elevation,
  }) {
    return BoxDecoration(
      color: color ?? surfaceColor,
      borderRadius: BorderRadius.circular(borderRadius ?? borderRadiusM),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.1),
          blurRadius: elevation ?? elevationM,
          offset: Offset(0, (elevation ?? elevationM) / 2),
        ),
      ],
    );
  }
}
