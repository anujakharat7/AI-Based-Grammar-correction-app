import 'dart:math' as math;

/// Voice Modulation Analysis Service
/// Provides comprehensive voice characteristic analysis including high, low, soft voice detection
class VoiceModulationService {
  static final VoiceModulationService _instance =
      VoiceModulationService._internal();
  factory VoiceModulationService() => _instance;
  VoiceModulationService._internal();

  // Voice tracking variables
  final List<double> _volumeLevels = [];
  final List<double> _pitchLevels = [];
  final List<Duration> _speechPauses = [];
  DateTime? _lastSpeechTime;

  // Analysis thresholds
  static const double _softVoiceThreshold = 0.2;
  static const double _normalVoiceThreshold = 0.6;
  static const double _loudVoiceThreshold = 0.8;
  static const double _lowPitchThreshold = 0.3;
  static const double _highPitchThreshold = 0.7;
  static const double _monotoneThreshold = 0.15;
  static const double _expressiveThreshold = 0.4;

  /// Reset all tracking data for a new recording session
  void resetTracking() {
    _volumeLevels.clear();
    _pitchLevels.clear();
    _speechPauses.clear();
    _lastSpeechTime = null;
  }

  /// Track volume level during speech (0.0 to 1.0)
  void trackVolumeLevel(double level) {
    if (level > 0.05) {
      // Only track meaningful sound levels
      _volumeLevels.add(level.clamp(0.0, 1.0));

      // Track speech pauses
      final now = DateTime.now();
      if (_lastSpeechTime != null) {
        final pause = now.difference(_lastSpeechTime!);
        if (pause.inMilliseconds > 200) {
          // Pause longer than 200ms
          _speechPauses.add(pause);
        }
      }
      _lastSpeechTime = now;
    }
  }

  /// Track pitch level during speech (estimated from volume variations)
  void trackPitchLevel(double level) {
    if (level > 0.05) {
      _pitchLevels.add(level.clamp(0.0, 1.0));
    }
  }

  /// Get comprehensive voice modulation analysis
  VoiceAnalysisResult getVoiceAnalysis() {
    if (_volumeLevels.isEmpty) {
      return VoiceAnalysisResult.empty();
    }

    // Calculate volume statistics
    final avgVolume =
        _volumeLevels.reduce((a, b) => a + b) / _volumeLevels.length;
    final maxVolume = _volumeLevels.reduce(math.max);
    final minVolume = _volumeLevels.reduce(math.min);
    final volumeRange = maxVolume - minVolume;

    // Calculate pitch statistics (using volume variations as proxy)
    final avgPitch = _pitchLevels.isNotEmpty
        ? _pitchLevels.reduce((a, b) => a + b) / _pitchLevels.length
        : avgVolume;

    // Analyze volume characteristics
    final volumeType = _analyzeVolumeType(avgVolume);
    final pitchType = _analyzePitchType(avgPitch);
    final expressiveness = _analyzeExpressiveness(volumeRange);
    final speakingRhythm = _analyzeSpeakingRhythm();

    return VoiceAnalysisResult(
      averageVolume: avgVolume,
      maxVolume: maxVolume,
      minVolume: minVolume,
      volumeRange: volumeRange,
      averagePitch: avgPitch,
      volumeType: volumeType,
      pitchType: pitchType,
      expressiveness: expressiveness,
      speakingRhythm: speakingRhythm,
      speechPauses: _speechPauses.length,
      averagePauseLength: _speechPauses.isNotEmpty
          ? _speechPauses.map((p) => p.inMilliseconds).reduce((a, b) => a + b) /
                _speechPauses.length
          : 0.0,
    );
  }

  /// Analyze volume type (Soft, Normal, Loud)
  VolumeType _analyzeVolumeType(double avgVolume) {
    if (avgVolume < _softVoiceThreshold) {
      return VolumeType.soft;
    } else if (avgVolume < _normalVoiceThreshold) {
      return VolumeType.normal;
    } else if (avgVolume < _loudVoiceThreshold) {
      return VolumeType.loud;
    } else {
      return VolumeType.veryLoud;
    }
  }

  /// Analyze pitch type (Low, Normal, High)
  PitchType _analyzePitchType(double avgPitch) {
    if (avgPitch < _lowPitchThreshold) {
      return PitchType.low;
    } else if (avgPitch < _highPitchThreshold) {
      return PitchType.normal;
    } else {
      return PitchType.high;
    }
  }

  /// Analyze expressiveness based on volume variation
  Expressiveness _analyzeExpressiveness(double volumeRange) {
    if (volumeRange < _monotoneThreshold) {
      return Expressiveness.monotone;
    } else if (volumeRange < _expressiveThreshold) {
      return Expressiveness.moderate;
    } else {
      return Expressiveness.expressive;
    }
  }

  /// Analyze speaking rhythm based on pauses
  SpeakingRhythm _analyzeSpeakingRhythm() {
    if (_speechPauses.isEmpty) {
      return SpeakingRhythm.steady;
    }

    final avgPause =
        _speechPauses.map((p) => p.inMilliseconds).reduce((a, b) => a + b) /
        _speechPauses.length;

    if (avgPause < 300) {
      return SpeakingRhythm.fast;
    } else if (avgPause < 800) {
      return SpeakingRhythm.steady;
    } else {
      return SpeakingRhythm.slow;
    }
  }

  /// Generate user-friendly recommendations based on voice analysis
  List<String> generateRecommendations(VoiceAnalysisResult analysis) {
    final recommendations = <String>[];

    // Volume recommendations
    switch (analysis.volumeType) {
      case VolumeType.soft:
        recommendations.add(
          'Try speaking louder and projecting your voice more confidently',
        );
        break;
      case VolumeType.veryLoud:
        recommendations.add(
          'Your voice is quite loud - try speaking more softly for better clarity',
        );
        break;
      case VolumeType.normal:
      case VolumeType.loud:
        recommendations.add('Great volume level! Your voice projects well');
        break;
    }

    // Pitch recommendations
    switch (analysis.pitchType) {
      case PitchType.low:
        recommendations.add(
          'Try varying your pitch more - add some higher tones for expressiveness',
        );
        break;
      case PitchType.high:
        recommendations.add(
          'Try adding some lower tones to your speech for more depth',
        );
        break;
      case PitchType.normal:
        recommendations.add(
          'Good pitch range! Your voice has nice natural variation',
        );
        break;
    }

    // Expressiveness recommendations
    switch (analysis.expressiveness) {
      case Expressiveness.monotone:
        recommendations.add(
          'Add more emotion and variation to your voice - vary your pitch and volume',
        );
        break;
      case Expressiveness.moderate:
        recommendations.add(
          'Good vocal variety! Consider adding even more dynamic range',
        );
        break;
      case Expressiveness.expressive:
        recommendations.add(
          'Excellent expressiveness! Your voice is very dynamic and engaging',
        );
        break;
    }

    // Rhythm recommendations
    switch (analysis.speakingRhythm) {
      case SpeakingRhythm.fast:
        recommendations.add(
          'Try slowing down your speech and adding more pauses for clarity',
        );
        break;
      case SpeakingRhythm.slow:
        recommendations.add(
          'You can speak a bit faster and reduce long pauses',
        );
        break;
      case SpeakingRhythm.steady:
        recommendations.add('Perfect speaking pace! Good use of pauses');
        break;
    }

    return recommendations;
  }
}

/// Voice analysis result containing all voice characteristics
class VoiceAnalysisResult {
  final double averageVolume;
  final double maxVolume;
  final double minVolume;
  final double volumeRange;
  final double averagePitch;
  final VolumeType volumeType;
  final PitchType pitchType;
  final Expressiveness expressiveness;
  final SpeakingRhythm speakingRhythm;
  final int speechPauses;
  final double averagePauseLength;

  const VoiceAnalysisResult({
    required this.averageVolume,
    required this.maxVolume,
    required this.minVolume,
    required this.volumeRange,
    required this.averagePitch,
    required this.volumeType,
    required this.pitchType,
    required this.expressiveness,
    required this.speakingRhythm,
    required this.speechPauses,
    required this.averagePauseLength,
  });

  factory VoiceAnalysisResult.empty() {
    return const VoiceAnalysisResult(
      averageVolume: 0.0,
      maxVolume: 0.0,
      minVolume: 0.0,
      volumeRange: 0.0,
      averagePitch: 0.0,
      volumeType: VolumeType.soft,
      pitchType: PitchType.normal,
      expressiveness: Expressiveness.monotone,
      speakingRhythm: SpeakingRhythm.steady,
      speechPauses: 0,
      averagePauseLength: 0.0,
    );
  }

  /// Get a formatted summary of the voice analysis
  String getSummary() {
    return '''Voice Characteristics:
• Volume: ${volumeType.displayName} (avg: ${(averageVolume * 100).toStringAsFixed(1)}%)
• Pitch: ${pitchType.displayName}
• Expressiveness: ${expressiveness.displayName}
• Speaking Rhythm: ${speakingRhythm.displayName}
• Volume Range: ${(volumeRange * 100).toStringAsFixed(1)}% variation
• Speech Pauses: $speechPauses pauses (avg: ${averagePauseLength.toStringAsFixed(0)}ms)''';
  }
}

/// Volume level categories
enum VolumeType {
  soft('Soft/Quiet'),
  normal('Normal'),
  loud('Loud'),
  veryLoud('Very Loud');

  const VolumeType(this.displayName);
  final String displayName;
}

/// Pitch level categories
enum PitchType {
  low('Low'),
  normal('Normal'),
  high('High');

  const PitchType(this.displayName);
  final String displayName;
}

/// Expressiveness categories
enum Expressiveness {
  monotone('Monotone'),
  moderate('Moderate'),
  expressive('Expressive');

  const Expressiveness(this.displayName);
  final String displayName;
}

/// Speaking rhythm categories
enum SpeakingRhythm {
  fast('Fast'),
  steady('Steady'),
  slow('Slow');

  const SpeakingRhythm(this.displayName);
  final String displayName;
}
