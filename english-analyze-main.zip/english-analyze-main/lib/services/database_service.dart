import 'package:supabase_flutter/supabase_flutter.dart';
import '../config/app_config.dart';

/// Database Service for managing user data and app content
class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  factory DatabaseService() => _instance;
  DatabaseService._internal();

  SupabaseClient get _client => Supabase.instance.client;

  /// Check if database service is configured
  bool get isConfigured => AppConfig.isSupabaseConfigured;

  // ================================
  // USER MANAGEMENT
  // ================================

  /// Get current user
  User? get currentUser => _client.auth.currentUser;

  /// Check if user is authenticated
  bool get isAuthenticated => currentUser != null;

  /// Sign up new user
  Future<AuthResponse> signUp({
    required String email,
    required String password,
    String? username,
  }) async {
    try {
      final response = await _client.auth.signUp(
        email: email,
        password: password,
        data: username != null ? {'username': username} : null,
      );
      return response;
    } catch (e) {
      throw Exception('Sign up failed: $e');
    }
  }

  /// Sign in existing user
  Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final response = await _client.auth.signInWithPassword(
        email: email,
        password: password,
      );
      return response;
    } catch (e) {
      throw Exception('Sign in failed: $e');
    }
  }

  /// Sign out current user
  Future<void> signOut() async {
    try {
      await _client.auth.signOut();
    } catch (e) {
      throw Exception('Sign out failed: $e');
    }
  }

  // ================================
  // USER PROFILE MANAGEMENT
  // ================================

  /// Get user profile data
  Future<Map<String, dynamic>?> getUserProfile(String userId) async {
    try {
      final response = await _client
          .from('user_profiles')
          .select()
          .eq('user_id', userId)
          .maybeSingle();
      return response;
    } catch (e) {
      if (AppConfig.enableDebugLogging) {
        print('Error getting user profile: $e');
      }
      return null;
    }
  }

  /// Update user profile
  Future<bool> updateUserProfile({
    required String userId,
    String? username,
    String? fullName,
    Map<String, dynamic>? preferences,
  }) async {
    try {
      final updateData = <String, dynamic>{};
      if (username != null) updateData['username'] = username;
      if (fullName != null) updateData['full_name'] = fullName;
      if (preferences != null) updateData['preferences'] = preferences;

      if (updateData.isNotEmpty) {
        updateData['updated_at'] = DateTime.now().toIso8601String();

        await _client.from('user_profiles').upsert({
          'user_id': userId,
          ...updateData,
        });
      }
      return true;
    } catch (e) {
      if (AppConfig.enableDebugLogging) {
        print('Error updating user profile: $e');
      }
      return false;
    }
  }

  // ================================
  // PRACTICE HISTORY MANAGEMENT
  // ================================

  /// Save practice session result
  Future<bool> savePracticeSession({
    required String userId,
    required String practiceType, // 'paragraph', 'sentence', 'speech_analyzer'
    required String content,
    required Map<String, dynamic> results,
    double? score,
  }) async {
    try {
      await _client.from('practice_sessions').insert({
        'user_id': userId,
        'practice_type': practiceType,
        'content': content,
        'results': results,
        'score': score,
        'created_at': DateTime.now().toIso8601String(),
      });
      return true;
    } catch (e) {
      if (AppConfig.enableDebugLogging) {
        print('Error saving practice session: $e');
      }
      return false;
    }
  }

  /// Get user's practice history
  Future<List<Map<String, dynamic>>> getPracticeHistory({
    required String userId,
    int limit = 20,
    String? practiceType,
  }) async {
    try {
      PostgrestTransformBuilder query = _client
          .from('practice_sessions')
          .select()
          .eq('user_id', userId)
          .order('created_at', ascending: false)
          .limit(limit);

      if (practiceType != null) {
        // Create a new query with the additional filter
        final response = await _client
            .from('practice_sessions')
            .select()
            .eq('user_id', userId)
            .eq('practice_type', practiceType)
            .order('created_at', ascending: false)
            .limit(limit);
        return List<Map<String, dynamic>>.from(response);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (AppConfig.enableDebugLogging) {
        print('Error getting practice history: $e');
      }
      return [];
    }
  }

  /// Get user statistics
  Future<Map<String, dynamic>> getUserStatistics(String userId) async {
    try {
      // Get total sessions
      final totalSessions = await _client
          .from('practice_sessions')
          .select('id')
          .eq('user_id', userId)
          .count();

      // Get average score
      final scoresResponse = await _client
          .from('practice_sessions')
          .select('score')
          .eq('user_id', userId)
          .not('score', 'is', null);

      double averageScore = 0.0;
      if (scoresResponse.isNotEmpty) {
        final scores = scoresResponse
            .map((s) => (s['score'] as num?)?.toDouble() ?? 0.0)
            .where((s) => s > 0)
            .toList();

        if (scores.isNotEmpty) {
          averageScore = scores.reduce((a, b) => a + b) / scores.length;
        }
      }

      // Get streak (consecutive days with practice)
      final recentSessions = await _client
          .from('practice_sessions')
          .select('created_at')
          .eq('user_id', userId)
          .order('created_at', ascending: false)
          .limit(100);

      int currentStreak = 0;
      if (recentSessions.isNotEmpty) {
        currentStreak = _calculateStreak(recentSessions);
      }

      return {
        'totalSessions': totalSessions.count,
        'averageScore': averageScore.round(),
        'currentStreak': currentStreak,
        'lastPractice': recentSessions.isNotEmpty
            ? recentSessions.first['created_at']
            : null,
      };
    } catch (e) {
      if (AppConfig.enableDebugLogging) {
        print('Error getting user statistics: $e');
      }
      return {
        'totalSessions': 0,
        'averageScore': 0,
        'currentStreak': 0,
        'lastPractice': null,
      };
    }
  }

  // ================================
  // LEADERBOARD MANAGEMENT
  // ================================

  /// Get leaderboard data
  Future<List<Map<String, dynamic>>> getLeaderboard({
    int limit = 10,
    String period = 'all_time', // 'weekly', 'monthly', 'all_time'
  }) async {
    try {
      String dateFilter = '';
      switch (period) {
        case 'weekly':
          dateFilter = DateTime.now()
              .subtract(const Duration(days: 7))
              .toIso8601String();
          break;
        case 'monthly':
          dateFilter = DateTime.now()
              .subtract(const Duration(days: 30))
              .toIso8601String();
          break;
      }

      PostgrestTransformBuilder query = _client
          .from(
            'leaderboard_view',
          ) // Assuming a database view that aggregates scores
          .select('user_id, username, average_score, total_sessions')
          .order('average_score', ascending: false)
          .limit(limit);

      if (dateFilter.isNotEmpty) {
        // Create a new query with date filter
        final response = await _client
            .from('leaderboard_view')
            .select('user_id, username, average_score, total_sessions')
            .gte('last_practice', dateFilter)
            .order('average_score', ascending: false)
            .limit(limit);
        return List<Map<String, dynamic>>.from(response);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (AppConfig.enableDebugLogging) {
        print('Error getting leaderboard: $e');
      }
      return [];
    }
  }

  // ================================
  // CONTENT MANAGEMENT
  // ================================

  /// Get practice paragraphs from database
  Future<List<String>> getPracticeParagraphs() async {
    try {
      final response = await _client
          .from('practice_content')
          .select('content')
          .eq('type', 'paragraph')
          .eq('is_active', true);

      if (response.isNotEmpty) {
        return response
            .map<String>((item) => item['content']?.toString() ?? '')
            .where((content) => content.isNotEmpty)
            .toList();
      }
    } catch (e) {
      if (AppConfig.enableDebugLogging) {
        print('Error getting practice paragraphs: $e');
      }
    }

    // Return default content if database fails
    return AppConfig.defaultParagraphs;
  }

  /// Get practice sentences from database
  Future<List<String>> getPracticeSentences() async {
    try {
      final response = await _client
          .from('practice_content')
          .select('content')
          .eq('type', 'sentence')
          .eq('is_active', true);

      if (response.isNotEmpty) {
        return response
            .map<String>((item) => item['content']?.toString() ?? '')
            .where((content) => content.isNotEmpty)
            .toList();
      }
    } catch (e) {
      if (AppConfig.enableDebugLogging) {
        print('Error getting practice sentences: $e');
      }
    }

    // Return default content if database fails
    return AppConfig.defaultSentences;
  }

  // ================================
  // UTILITY METHODS
  // ================================

  /// Calculate consecutive practice days streak
  int _calculateStreak(List<Map<String, dynamic>> sessions) {
    if (sessions.isEmpty) return 0;

    int streak = 0;
    DateTime currentDate = DateTime.now();
    Set<String> practiceDays = {};

    for (final session in sessions) {
      final sessionDate = DateTime.parse(session['created_at']);
      final dayKey =
          '${sessionDate.year}-${sessionDate.month}-${sessionDate.day}';
      practiceDays.add(dayKey);
    }

    // Check consecutive days backwards from today
    for (int i = 0; i < 365; i++) {
      // Check up to a year back
      final checkDate = currentDate.subtract(Duration(days: i));
      final dayKey = '${checkDate.year}-${checkDate.month}-${checkDate.day}';

      if (practiceDays.contains(dayKey)) {
        streak++;
      } else {
        break;
      }
    }

    return streak;
  }

  /// Get service status
  Map<String, dynamic> getStatus() {
    return {
      'configured': isConfigured,
      'authenticated': isAuthenticated,
      'currentUser': currentUser?.id,
      'userEmail': currentUser?.email,
    };
  }
}
