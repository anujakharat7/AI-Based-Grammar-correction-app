import 'dart:io';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import '../config/app_config.dart';
import 'voice_modulation_service.dart';

/// Audio Recording Service
/// Handles all audio recording functionality with consistent configuration
class AudioService {
  static final AudioService _instance = AudioService._internal();
  factory AudioService() => _instance;
  AudioService._internal();

  final AudioRecorder _audioRecorder = AudioRecorder();
  final VoiceModulationService _voiceService = VoiceModulationService();
  String? _currentRecordingPath;
  bool _isRecording = false;

  /// Check if currently recording
  bool get isRecording => _isRecording;

  /// Get current recording path
  String? get currentRecordingPath => _currentRecordingPath;

  /// Get voice analysis for current recording session
  VoiceAnalysisResult get voiceAnalysis => _voiceService.getVoiceAnalysis();

  /// Reset voice tracking for new recording session
  void resetVoiceTracking() => _voiceService.resetTracking();

  /// Track voice characteristics during recording (call this with audio level data)
  void trackVoiceLevel(double level) => _voiceService.trackVolumeLevel(level);

  /// Check if microphone permission is granted
  Future<bool> hasPermission() async {
    return await _audioRecorder.hasPermission();
  }

  /// Request microphone permission
  Future<bool> requestPermission() async {
    if (await hasPermission()) {
      return true;
    }
    return await _audioRecorder.hasPermission();
  }

  /// Start audio recording
  /// Returns the path where the recording will be saved
  Future<String> startRecording() async {
    if (_isRecording) {
      throw Exception('Recording already in progress');
    }

    if (!await requestPermission()) {
      throw Exception('Microphone permission not granted');
    }

    try {
      // Reset voice tracking for new session
      _voiceService.resetTracking();

      // Create temporary directory for recording
      final directory = await getTemporaryDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      _currentRecordingPath = '${directory.path}/recording_$timestamp.wav';

      // Start recording with optimized settings
      await _audioRecorder.start(
        RecordConfig(
          encoder: AudioEncoder.wav,
          bitRate: AppConfig.audioBitRate,
          sampleRate: AppConfig.audioSampleRate,
        ),
        path: _currentRecordingPath!,
      );

      _isRecording = true;
      return _currentRecordingPath!;
    } catch (e) {
      _isRecording = false;
      _currentRecordingPath = null;
      throw Exception('Failed to start recording: $e');
    }
  }

  /// Stop audio recording
  /// Returns the path of the recorded file
  Future<String?> stopRecording() async {
    if (!_isRecording) {
      throw Exception('No recording in progress');
    }

    try {
      final path = await _audioRecorder.stop();
      _isRecording = false;

      if (path != null && await isValidRecording(path)) {
        return path;
      } else {
        throw Exception('Recording failed or too short');
      }
    } catch (e) {
      _isRecording = false;
      throw Exception('Failed to stop recording: $e');
    } finally {
      _currentRecordingPath = null;
    }
  }

  /// Validate if recording is usable
  Future<bool> isValidRecording(String filePath) async {
    try {
      final file = File(filePath);

      if (!await file.exists()) {
        return false;
      }

      final fileSize = await file.length();
      return fileSize >= AppConfig.minAudioFileSizeBytes;
    } catch (e) {
      return false;
    }
  }

  /// Get recording duration in seconds
  Future<double> getRecordingDuration(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return 0.0;

      // This is a simplified calculation
      // For accurate duration, you'd need audio processing libraries
      final fileSize = await file.length();
      final bytesPerSecond =
          (AppConfig.audioSampleRate * AppConfig.audioBitRate / 8) / 1000;
      return fileSize / bytesPerSecond;
    } catch (e) {
      return 0.0;
    }
  }

  /// Clean up old recording files
  Future<void> cleanupOldRecordings() async {
    try {
      final directory = await getTemporaryDirectory();
      final recordings = directory
          .listSync()
          .where(
            (file) =>
                file.path.contains('recording_') && file.path.endsWith('.wav'),
          )
          .toList();

      for (final recording in recordings) {
        try {
          await recording.delete();
        } catch (e) {
          // Ignore individual file deletion errors
        }
      }
    } catch (e) {
      // Ignore cleanup errors
    }
  }

  /// Dispose resources
  void dispose() {
    _audioRecorder.dispose();
    _isRecording = false;
    _currentRecordingPath = null;
  }
}
