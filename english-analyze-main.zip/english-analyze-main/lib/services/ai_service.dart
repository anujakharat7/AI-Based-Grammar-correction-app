import 'package:google_generative_ai/google_generative_ai.dart';
import '../config/app_config.dart';

/// AI Service for Gemini integration
/// Handles speech transcription and pronunciation analysis
class AIService {
  static final AIService _instance = AIService._internal();
  factory AIService() => _instance;
  AIService._internal();

  GenerativeModel? _currentModel;
  int _currentModelIndex = 0;

  /// Check if AI service is configured and ready
  bool get isConfigured => AppConfig.isGeminiConfigured;

  /// Initialize the AI service with the first available model
  Future<bool> initialize() async {
    if (!isConfigured) {
      return false;
    }

    try {
      _currentModelIndex = 0;
      _currentModel = GenerativeModel(
        model: AppConfig.geminiModels[_currentModelIndex],
        apiKey: AppConfig.geminiApiKey,
      );
      return true;
    } catch (e) {
      if (AppConfig.enableDebugLogging) {
        print('Error initializing AI service: $e');
      }
      return false;
    }
  }

  /// Transcribe audio to text
  Future<String?> transcribeAudio(String audioPath) async {
    const prompt = '''
You are an advanced speech recognition AI. The user has recorded themselves speaking in English.

Your task: Transcribe exactly what the person said.

Instructions:
- Transcribe the spoken words as accurately as possible
- Use standard spelling and punctuation  
- If multiple sentences, separate them appropriately
- Make your best guess for unclear words based on context
- Respond with ONLY the transcribed text, nothing else

Example response: "Hello, how are you today?"
''';

    return await _callWithFallback(prompt);
  }

  /// Analyze pronunciation and provide detailed feedback
  Future<String?> analyzePronunciation(String transcribedText) async {
    final prompt =
        '''
You are an expert English pronunciation analyst. The user spoke this text:

"$transcribedText"

Based on their audio recording, provide a detailed pronunciation assessment:

SCORING CRITERIA:
- Consonant clarity (th, r, l, s, z sounds)
- Vowel accuracy and distinction  
- Word stress patterns
- Overall fluency and rhythm
- Common non-native pronunciation challenges

Format your response EXACTLY like this:

SCORE: [number from 0-100]/100
TRANSCRIPTION: $transcribedText
WORD_ANALYSIS:
- [word1]: [Good/Fair/Poor] - [brief reason if Fair/Poor]
- [word2]: [Good/Fair/Poor] - [brief reason if Fair/Poor]
ISSUES: [Main pronunciation problems detected]
TIPS: [2-3 specific improvement suggestions]

Example:
SCORE: 85/100
TRANSCRIPTION: Hello how are you
WORD_ANALYSIS:
- Hello: Good
- how: Fair - weak 'h' sound
- are: Good  
- you: Poor - pronounced as 'yu' instead of 'you'
ISSUES: Weak initial consonants, vowel reduction in unstressed syllables
TIPS: Practice stronger consonant sounds, slow down speech for clarity, focus on vowel distinction
''';

    return await _callWithFallback(prompt);
  }

  /// Generate practice sentences based on difficulty level
  Future<List<String>?> generatePracticeSentences({
    required String difficultyLevel, // 'beginner', 'intermediate', 'advanced'
    int count = 5,
  }) async {
    final prompt =
        '''
Generate $count English pronunciation practice sentences for $difficultyLevel level learners.

Requirements:
- Focus on common pronunciation challenges for non-native speakers
- Include varied sentence structures and vocabulary
- Each sentence should be 8-15 words long
- Return ONLY the sentences, one per line
- No numbering or additional text

Difficulty guidelines:
- Beginner: Simple words, common sounds, basic sentence structure
- Intermediate: Mixed consonant clusters, varied vowel sounds, compound sentences
- Advanced: Complex phonemes, tongue twisters, advanced vocabulary

Example output:
The cat sits on the red mat.
She sells seashells by the seashore.
''';

    final response = await _callWithFallback(prompt);
    if (response != null) {
      return response
          .split('\n')
          .map((s) => s.trim())
          .where((s) => s.isNotEmpty)
          .toList();
    }
    return null;
  }

  /// Generate a pronunciation exercise for specific sounds
  Future<String?> generateSoundExercise(String targetSound) async {
    final prompt =
        '''
Create a pronunciation exercise focusing on the "$targetSound" sound in English.

Include:
1. A brief explanation of how to produce the sound
2. 5-7 words that contain this sound in different positions
3. 2-3 practice sentences using these words

Format your response like this:

SOUND: $targetSound
HOW TO PRONOUNCE: [brief explanation]
PRACTICE WORDS: [word1, word2, word3, ...]
PRACTICE SENTENCES:
- [sentence 1]
- [sentence 2]
- [sentence 3]

Keep explanations simple and practical.
''';

    return await _callWithFallback(prompt);
  }

  /// Call Gemini AI with automatic fallback to different models
  Future<String?> _callWithFallback(String prompt) async {
    if (!isConfigured) {
      if (AppConfig.enableDebugLogging) {
        print('AI service not configured');
      }
      return null;
    }

    String? lastError;

    // Try each model in order
    for (int attempt = 0; attempt < AppConfig.geminiModels.length; attempt++) {
      try {
        final modelName = AppConfig.geminiModels[attempt];

        // Switch model if needed
        if (_currentModel == null || _currentModelIndex != attempt) {
          _currentModel = GenerativeModel(
            model: modelName,
            apiKey: AppConfig.geminiApiKey,
          );
          _currentModelIndex = attempt;
        }

        if (AppConfig.enableDebugLogging) {
          print('Trying model: $modelName');
        }

        // Make the API call
        final content = [Content.text(prompt)];
        final response = await _currentModel!
            .generateContent(content)
            .timeout(Duration(seconds: AppConfig.geminiTimeoutSeconds));

        if (response.text != null && response.text!.isNotEmpty) {
          return _cleanResponse(response.text!);
        }
      } catch (e) {
        lastError = e.toString();
        if (AppConfig.enableDebugLogging) {
          print('Error with model ${AppConfig.geminiModels[attempt]}: $e');
        }
      }
    }

    if (AppConfig.enableDebugLogging) {
      print('All models failed. Last error: $lastError');
    }
    return null;
  }

  /// Clean up AI response text
  String _cleanResponse(String text) {
    // Remove surrounding quotes
    text = text.trim();
    if ((text.startsWith('"') && text.endsWith('"')) ||
        (text.startsWith("'") && text.endsWith("'"))) {
      text = text.substring(1, text.length - 1);
    }

    // Clean up excessive whitespace and newlines
    text = text.replaceAll(RegExp(r'\n+'), ' ').trim();

    return text;
  }

  /// Get service status information
  Map<String, dynamic> getStatus() {
    return {
      'configured': isConfigured,
      'currentModel': _currentModel != null
          ? AppConfig.geminiModels[_currentModelIndex]
          : null,
      'availableModels': AppConfig.geminiModels,
      'timeoutSeconds': AppConfig.geminiTimeoutSeconds,
      'maxRetryAttempts': AppConfig.geminiMaxRetryAttempts,
    };
  }

  /// Reset to first model (useful after errors)
  Future<void> reset() async {
    _currentModel = null;
    _currentModelIndex = 0;
    await initialize();
  }
}
