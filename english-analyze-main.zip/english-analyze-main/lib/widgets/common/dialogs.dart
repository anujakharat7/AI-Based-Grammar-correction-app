import 'package:flutter/material.dart';
import '../../utils/app_theme.dart';

/// Loading Dialog Widget
/// Shows a loading indicator with customizable message
class LoadingDialog extends StatelessWidget {
  final String message;

  const LoadingDialog({super.key, this.message = 'Loading...'});

  /// Show loading dialog
  static void show(BuildContext context, String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => LoadingDialog(message: message),
    );
  }

  /// Hide loading dialog
  static void hide(BuildContext context) {
    if (Navigator.canPop(context)) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      content: Row(
        children: [
          const CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
          ),
          const SizedBox(width: AppTheme.spacingM),
          Expanded(child: Text(message, style: AppTheme.bodyMedium)),
        ],
      ),
    );
  }
}

/// Error Dialog Widget
/// Shows error messages with consistent styling
class ErrorDialog extends StatelessWidget {
  final String title;
  final String message;
  final VoidCallback? onOk;

  const ErrorDialog({
    super.key,
    required this.title,
    required this.message,
    this.onOk,
  });

  /// Show error dialog
  static void show(
    BuildContext context,
    String title,
    String message, {
    VoidCallback? onOk,
  }) {
    showDialog(
      context: context,
      builder: (context) =>
          ErrorDialog(title: title, message: message, onOk: onOk),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Row(
        children: [
          const Icon(Icons.error, color: AppTheme.errorColor),
          const SizedBox(width: AppTheme.spacingS),
          Text(title, style: AppTheme.titleMedium),
        ],
      ),
      content: Text(message, style: AppTheme.bodyMedium),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.pop(context);
            onOk?.call();
          },
          child: const Text('OK'),
        ),
      ],
    );
  }
}

/// Success Dialog Widget
/// Shows success messages with positive styling
class SuccessDialog extends StatelessWidget {
  final String title;
  final String message;
  final VoidCallback? onOk;

  const SuccessDialog({
    super.key,
    required this.title,
    required this.message,
    this.onOk,
  });

  /// Show success dialog
  static void show(
    BuildContext context,
    String title,
    String message, {
    VoidCallback? onOk,
  }) {
    showDialog(
      context: context,
      builder: (context) =>
          SuccessDialog(title: title, message: message, onOk: onOk),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Row(
        children: [
          const Icon(Icons.check_circle, color: AppTheme.successColor),
          const SizedBox(width: AppTheme.spacingS),
          Text(title, style: AppTheme.titleMedium),
        ],
      ),
      content: Text(message, style: AppTheme.bodyMedium),
      actions: [
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
            onOk?.call();
          },
          child: const Text('OK'),
        ),
      ],
    );
  }
}

/// Confirmation Dialog Widget
/// Shows confirmation dialogs with Yes/No options
class ConfirmationDialog extends StatelessWidget {
  final String title;
  final String message;
  final VoidCallback? onConfirm;
  final VoidCallback? onCancel;
  final String confirmText;
  final String cancelText;

  const ConfirmationDialog({
    super.key,
    required this.title,
    required this.message,
    this.onConfirm,
    this.onCancel,
    this.confirmText = 'Yes',
    this.cancelText = 'No',
  });

  /// Show confirmation dialog
  static void show(
    BuildContext context,
    String title,
    String message, {
    VoidCallback? onConfirm,
    VoidCallback? onCancel,
    String confirmText = 'Yes',
    String cancelText = 'No',
  }) {
    showDialog(
      context: context,
      builder: (context) => ConfirmationDialog(
        title: title,
        message: message,
        onConfirm: onConfirm,
        onCancel: onCancel,
        confirmText: confirmText,
        cancelText: cancelText,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(title, style: AppTheme.titleMedium),
      content: Text(message, style: AppTheme.bodyMedium),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.pop(context);
            onCancel?.call();
          },
          child: Text(cancelText),
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
            onConfirm?.call();
          },
          child: Text(confirmText),
        ),
      ],
    );
  }
}
