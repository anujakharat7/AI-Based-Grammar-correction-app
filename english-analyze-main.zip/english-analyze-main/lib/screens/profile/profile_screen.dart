import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:fl_chart/fl_chart.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final client = Supabase.instance.client;
  bool isLoading = true;
  String username = '';
  int level = 1;
  int xp = 0;
  int streak = 0;
  int sentencesPracticed = 0;
  List<dynamic> achievements = [];
  List<String> lowestWords = [];
  List<FlSpot> chartSpots = [];

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final user = client.auth.currentUser;
    if (user == null) return;

    try {
      // Fetch user profile
      final profileRes = await client
          .from('profiles')
          .select('username, level, xp, streak, sentences_practiced')
          .eq('id', user.id)
          .single();

      setState(() {
        username = profileRes['username'] ?? '';
        level = profileRes['level'] ?? 1;
        xp = profileRes['xp'] ?? 0;
        streak = profileRes['streak'] ?? 0;
        sentencesPracticed = profileRes['sentences_practiced'] ?? 0;
      });

      // Fetch achievements
      final achievementRes = await client
          .from('user_achievements')
          .select('achievement_id')
          .eq('user_id', user.id);

      setState(() {
        achievements = achievementRes;
      });

      // Fetch progress chart data
      final scoresRes = await client
          .from('pronunciation_scores')
          .select('score, created_at')
          .eq('user_id', user.id)
          .order('created_at', ascending: true)
          .limit(20);

      if (scoresRes.isNotEmpty) {
        setState(() {
          chartSpots = (scoresRes as List<dynamic>)
              .asMap()
              .entries
              .map(
                (entry) => FlSpot(
                  entry.key.toDouble(),
                  (entry.value['score'] as num).toDouble(),
                ),
              )
              .toList();
        });
      }
    } catch (e) {
      print('Error loading profile: $e');
      setState(() {
        level = 1;
        xp = 0;
        streak = 0;
        sentencesPracticed = 0;
        achievements = [];
        chartSpots = [];
      });
    }

    try {
      // Fetch lowest scoring words
      final wordRes = await client
          .from('pronunciation_scores')
          .select('word, score')
          .eq('user_id', user.id)
          .order('score', ascending: true)
          .limit(5);
      setState(() {
        lowestWords =
            (wordRes as List<dynamic>?)
                ?.map((e) => e['word'] as String)
                .toList() ??
            [];
      });
    } catch (e) {
      print('Error fetching lowest scoring words: $e');
      setState(() {
        lowestWords = [];
      });
    }

    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Profile'), centerTitle: true),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF7C4DFF), Color(0xFFcfdef3)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          Center(
            child: SafeArea(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16.0,
                    vertical: 20.0,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(32),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.08),
                          blurRadius: 24,
                          offset: const Offset(0, 8),
                        ),
                      ],
                      border: Border.all(
                        color: Colors.white.withOpacity(0.3),
                        width: 1.5,
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(32),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                        child: Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              // Profile Header
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: const LinearGradient(
                                        colors: [
                                          Color(0xFF7C4DFF),
                                          Color(0xFF448AFF),
                                        ],
                                      ),
                                    ),
                                    child: const CircleAvatar(
                                      radius: 40,
                                      backgroundColor: Colors.transparent,
                                      child: Icon(
                                        Icons.person,
                                        size: 40,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              Container(
                                constraints: const BoxConstraints(
                                  maxHeight: 60,
                                ),
                                child: Text(
                                  username.isNotEmpty
                                      ? username
                                      : 'Anonymous User',
                                  style: const TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF3a3a3a),
                                  ),
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Level $level',
                                style: const TextStyle(
                                  fontSize: 18,
                                  color: Color(0xFF7C4DFF),
                                ),
                              ),
                              const SizedBox(height: 8),
                              LinearProgressIndicator(
                                value: xp / 2000,
                                minHeight: 8,
                                backgroundColor: Colors.grey.shade300,
                                color: const Color(0xFF7C4DFF),
                              ),
                              const SizedBox(height: 24),

                              // Stats Cards
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  _StatCard(label: 'Streak', value: '$streak'),
                                  _StatCard(
                                    label: 'Practiced',
                                    value: '$sentencesPracticed',
                                  ),
                                  _StatCard(
                                    label: 'Achievements',
                                    value: '${achievements.length}',
                                  ),
                                ],
                              ),
                              const SizedBox(height: 32),

                              // Progress Chart
                              const Text(
                                'Progress',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF3a3a3a),
                                ),
                              ),
                              const SizedBox(height: 16),
                              Container(
                                height: 200,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.85),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: chartSpots.isEmpty
                                    ? const Center(
                                        child: Text(
                                          'No progress data yet',
                                          style: TextStyle(color: Colors.grey),
                                        ),
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.all(16.0),
                                        child: LineChart(
                                          LineChartData(
                                            lineBarsData: [
                                              LineChartBarData(
                                                spots: chartSpots,
                                                isCurved: true,
                                                color: const Color(0xFF7C4DFF),
                                                barWidth: 3,
                                                dotData: const FlDotData(
                                                  show: false,
                                                ),
                                              ),
                                            ],
                                            titlesData: const FlTitlesData(
                                              show: false,
                                            ),
                                            gridData: const FlGridData(
                                              show: false,
                                            ),
                                            borderData: FlBorderData(
                                              show: false,
                                            ),
                                          ),
                                        ),
                                      ),
                              ),
                              const SizedBox(height: 24),

                              // Personalized Practice
                              const Text(
                                'Personalized Practice',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF3a3a3a),
                                ),
                              ),
                              const SizedBox(height: 12),
                              Container(
                                constraints: const BoxConstraints(
                                  maxHeight: 150, // Limit words list height
                                ),
                                child: lowestWords.isEmpty
                                    ? const Center(
                                        child: Text(
                                          'No practice words yet',
                                          style: TextStyle(color: Colors.grey),
                                        ),
                                      )
                                    : ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: lowestWords.length,
                                        itemBuilder: (context, i) => Card(
                                          elevation: 0,
                                          color: Colors.white.withOpacity(0.85),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                          ),
                                          child: ListTile(
                                            leading: const Icon(
                                              Icons.volume_up,
                                              color: Color(0xFF7C4DFF),
                                            ),
                                            title: Text(
                                              lowestWords[i],
                                              style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                color: Color(0xFF3a3a3a),
                                              ),
                                            ),
                                            subtitle: const Text(
                                              'Needs Practice',
                                              style: TextStyle(
                                                color: Colors.grey,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                              ),
                              const SizedBox(height: 24),

                              // Achievements
                              const Text(
                                'Achievements',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF3a3a3a),
                                ),
                              ),
                              const SizedBox(height: 12),
                              Container(
                                constraints: const BoxConstraints(
                                  maxHeight:
                                      200, // Limit achievements grid height
                                ),
                                child: achievements.isEmpty
                                    ? const Center(
                                        child: Text(
                                          'No achievements yet',
                                          style: TextStyle(color: Colors.grey),
                                        ),
                                      )
                                    : GridView.count(
                                        shrinkWrap: true,
                                        crossAxisCount: 3,
                                        mainAxisSpacing: 8,
                                        crossAxisSpacing: 8,
                                        childAspectRatio: 1.2,
                                        children: achievements
                                            .map(
                                              (a) => Card(
                                                elevation: 0,
                                                color: Colors.white.withOpacity(
                                                  0.85,
                                                ),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(12),
                                                ),
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    const Icon(
                                                      Icons.star,
                                                      size: 36,
                                                      color: Color(0xFF7C4DFF),
                                                    ),
                                                    Text(
                                                      '${a['achievement_id']}',
                                                      style: const TextStyle(
                                                        fontSize: 14,
                                                        color: Color(
                                                          0xFF3a3a3a,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            )
                                            .toList(),
                                      ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  const _StatCard({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        child: Column(
          children: [
            Text(
              value,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(fontSize: 14, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
