import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../../config/api_config.dart';
import 'speech_analyzer_screen.dart';

// Practice modes
enum PracticeMode { paragraph, sentence, custom, analyzer }

class ParagraphPracticePage extends StatefulWidget {
  const ParagraphPracticePage({super.key});

  @override
  State<ParagraphPracticePage> createState() => _ParagraphPracticePageState();
}

class _ParagraphPracticePageState extends State<ParagraphPracticePage>
    with TickerProviderStateMixin {
  PracticeMode currentMode = PracticeMode.paragraph;

  // Sample paragraphs for practice
  final List<Map<String, String>> paragraphs = [
    {
      'title': 'The Art of Communication',
      'content':
          'Effective communication is the cornerstone of human interaction. It involves not just speaking clearly, but also listening actively and understanding the nuances of language. When we communicate well, we build stronger relationships and achieve better outcomes in both personal and professional settings.',
    },
    {
      'title': 'Technology and Society',
      'content':
          'Technology has revolutionized the way we live, work, and connect with others. From smartphones to artificial intelligence, these innovations have transformed industries and created new possibilities. However, we must also consider the challenges they bring and work towards using technology responsibly.',
    },
    {
      'title': 'Environmental Conservation',
      'content':
          'Protecting our environment is one of the most pressing challenges of our time. Climate change, pollution, and deforestation threaten the delicate balance of ecosystems worldwide. Each individual can contribute by making sustainable choices and supporting conservation efforts in their community.',
    },
  ];

  // Practice sentences
  final List<String> practiceSentences = [
    'The quick brown fox jumps over the lazy dog.',
    'She sells seashells by the seashore.',
    'How much wood would a woodchuck chuck if a woodchuck could chuck wood?',
    'Peter Piper picked a peck of pickled peppers.',
    'The thirty-three thieves thought that they thrilled the throne.',
  ];

  int currentIndex = 0;
  bool isRecording = false;
  String recordingText = 'Tap to Start Recording';
  String? recordingPath;
  Map<String, dynamic>? analysisResults;
  bool isAnalyzing = false;
  bool showResults = false;

  // Custom text input
  final TextEditingController customTextController = TextEditingController();
  String customText = '';

  // Animation controllers
  late AnimationController _pulseController;
  late AnimationController _fadeController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _fadeAnimation;

  final FlutterTts flutterTts = FlutterTts();
  final AudioRecorder audioRecorder = AudioRecorder();

  // Gemini AI configuration
  GenerativeModel? geminiModel;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _setupTts();
    _initializeGemini();
  }

  void _setupAnimations() {
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.2).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _fadeController.forward();
  }

  Future<void> _setupTts() async {
    await flutterTts.setLanguage("en-US");
    await flutterTts.setPitch(1.0);
    await flutterTts.setSpeechRate(0.4);
  }

  void _initializeGemini() {
    if (ApiConfig.isGeminiConfigured) {
      geminiModel = GenerativeModel(
        model: 'gemini-1.5-flash',
        apiKey: ApiConfig.geminiApiKey,
      );
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _fadeController.dispose();
    customTextController.dispose();
    super.dispose();
  }

  String _getCurrentText() {
    switch (currentMode) {
      case PracticeMode.paragraph:
        return paragraphs[currentIndex]['content']!;
      case PracticeMode.sentence:
        return practiceSentences[currentIndex];
      case PracticeMode.custom:
        return customText.isNotEmpty
            ? customText
            : 'Please enter your text to practice';
      case PracticeMode.analyzer:
        return 'Free Speech Analysis Mode - Speak naturally';
    }
  }

  String _getCurrentTitle() {
    switch (currentMode) {
      case PracticeMode.paragraph:
        return paragraphs[currentIndex]['title']!;
      case PracticeMode.sentence:
        return 'Practice Sentence ${currentIndex + 1}';
      case PracticeMode.custom:
        return 'Custom Text Practice';
      case PracticeMode.analyzer:
        return 'Speech Pronunciation Analyzer';
    }
  }

  Future<void> _playText() async {
    await flutterTts.speak(_getCurrentText());
  }

  Future<void> _startRecording() async {
    try {
      if (await audioRecorder.hasPermission()) {
        final directory = await getApplicationDocumentsDirectory();
        recordingPath =
            '${directory.path}/practice_${DateTime.now().millisecondsSinceEpoch}.m4a';

        await audioRecorder.start(const RecordConfig(), path: recordingPath!);

        setState(() {
          isRecording = true;
          recordingText = 'Recording... Speak now!';
          showResults = false;
        });

        _pulseController.repeat(reverse: true);
      }
    } catch (e) {
      print('Error starting recording: $e');
    }
  }

  Future<void> _stopRecording() async {
    try {
      await audioRecorder.stop();
      _pulseController.stop();

      setState(() {
        isRecording = false;
        recordingText = 'Analyzing...';
        isAnalyzing = true;
      });

      // Simulate analysis
      await Future.delayed(const Duration(seconds: 2));

      // Create mock analysis results
      final mockResults = {
        'overall_score': 85,
        'feedback': 'Good pronunciation! Work on stress patterns.',
        'word_analysis': [
          {'word': 'example', 'score': 90, 'difficulty': 'easy'},
          {'word': 'pronunciation', 'score': 75, 'difficulty': 'hard'},
        ],
      };

      setState(() {
        analysisResults = mockResults;
        showResults = true;
        isAnalyzing = false;
        recordingText = 'Analysis Complete!';
      });
    } catch (e) {
      print('Error stopping recording: $e');
      setState(() {
        isRecording = false;
        recordingText = 'Error occurred';
        isAnalyzing = false;
      });
    }
  }

  void _nextItem() {
    setState(() {
      if (currentMode == PracticeMode.paragraph) {
        currentIndex = (currentIndex + 1) % paragraphs.length;
      } else if (currentMode == PracticeMode.sentence) {
        currentIndex = (currentIndex + 1) % practiceSentences.length;
      }
      showResults = false;
      analysisResults = null;
      recordingText = 'Tap to Start Recording';
    });
  }

  void _previousItem() {
    setState(() {
      if (currentMode == PracticeMode.paragraph) {
        currentIndex = currentIndex > 0
            ? currentIndex - 1
            : paragraphs.length - 1;
      } else if (currentMode == PracticeMode.sentence) {
        currentIndex = currentIndex > 0
            ? currentIndex - 1
            : practiceSentences.length - 1;
      }
      showResults = false;
      analysisResults = null;
      recordingText = 'Tap to Start Recording';
    });
  }

  void _switchMode(PracticeMode mode) {
    if (mode == PracticeMode.analyzer) {
      // Navigate to the dedicated speech analyzer
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const SpeechAnalyzer()),
      );
      return;
    }

    setState(() {
      currentMode = mode;
      currentIndex = 0;
      showResults = false;
      analysisResults = null;
      recordingText = 'Tap to Start Recording';
    });
  }

  void _setCustomText() {
    setState(() {
      customText = customTextController.text;
      showResults = false;
      analysisResults = null;
      recordingText = 'Tap to Start Recording';
    });
    Navigator.pop(context);
  }

  void _showCustomTextDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Enter Custom Text'),
        content: TextField(
          controller: customTextController,
          maxLines: 5,
          decoration: const InputDecoration(
            hintText: 'Enter text to practice pronunciation...',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: customTextController.text.isNotEmpty
                ? _setCustomText
                : null,
            child: const Text('Practice This Text'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.1),
              Theme.of(context).colorScheme.secondary.withOpacity(0.1),
            ],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: Column(
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 8),
                      const Expanded(
                        child: Text(
                          'Pronunciation Practice',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Mode Selection
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Expanded(
                        child: _ModeButton(
                          title: 'Paragraphs',
                          icon: Icons.article,
                          isSelected: currentMode == PracticeMode.paragraph,
                          onTap: () => _switchMode(PracticeMode.paragraph),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _ModeButton(
                          title: 'Sentences',
                          icon: Icons.format_quote,
                          isSelected: currentMode == PracticeMode.sentence,
                          onTap: () => _switchMode(PracticeMode.sentence),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _ModeButton(
                          title: 'Custom',
                          icon: Icons.edit,
                          isSelected: currentMode == PracticeMode.custom,
                          onTap: () => _switchMode(PracticeMode.custom),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _ModeButton(
                          title: 'Analyzer',
                          icon: Icons.analytics,
                          isSelected:
                              false, // Never selected since it navigates away
                          onTap: () => _switchMode(PracticeMode.analyzer),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Content
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Current Text Card
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        _getCurrentTitle(),
                                        style: const TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    if (currentMode != PracticeMode.custom &&
                                        currentMode != PracticeMode.analyzer)
                                      Row(
                                        children: [
                                          if (currentMode !=
                                              PracticeMode.analyzer)
                                            IconButton(
                                              onPressed: _previousItem,
                                              icon: const Icon(
                                                Icons.chevron_left,
                                              ),
                                            ),
                                          if (currentMode !=
                                              PracticeMode.analyzer)
                                            IconButton(
                                              onPressed: _nextItem,
                                              icon: const Icon(
                                                Icons.chevron_right,
                                              ),
                                            ),
                                        ],
                                      ),
                                  ],
                                ),
                                const SizedBox(height: 16),
                                Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: Colors.grey.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Text(
                                    _getCurrentText(),
                                    style: const TextStyle(
                                      fontSize: 16,
                                      height: 1.5,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                Row(
                                  children: [
                                    ElevatedButton.icon(
                                      onPressed: _playText,
                                      icon: const Icon(Icons.play_arrow),
                                      label: const Text('Listen'),
                                    ),
                                    const SizedBox(width: 12),
                                    if (currentMode == PracticeMode.custom)
                                      ElevatedButton.icon(
                                        onPressed: _showCustomTextDialog,
                                        icon: const Icon(Icons.edit),
                                        label: const Text('Edit Text'),
                                      ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(height: 20),

                        // Recording Section
                        if (showResults && analysisResults != null)
                          _buildResultsSection(),

                        const SizedBox(height: 20),

                        // Recording Button
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Column(
                              children: [
                                AnimatedBuilder(
                                  animation: _pulseAnimation,
                                  builder: (context, child) {
                                    return Transform.scale(
                                      scale: isRecording
                                          ? _pulseAnimation.value
                                          : 1.0,
                                      child: GestureDetector(
                                        onTap: isRecording
                                            ? _stopRecording
                                            : _startRecording,
                                        child: Container(
                                          width: 120,
                                          height: 120,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            gradient: LinearGradient(
                                              colors: isRecording
                                                  ? [
                                                      Colors.red,
                                                      Colors.redAccent,
                                                    ]
                                                  : [
                                                      Colors.blue,
                                                      Colors.blueAccent,
                                                    ],
                                            ),
                                            boxShadow: [
                                              BoxShadow(
                                                color:
                                                    (isRecording
                                                            ? Colors.red
                                                            : Colors.blue)
                                                        .withOpacity(0.3),
                                                blurRadius: 15,
                                                spreadRadius: 5,
                                              ),
                                            ],
                                          ),
                                          child: Icon(
                                            isRecording
                                                ? Icons.stop
                                                : Icons.mic,
                                            size: 48,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  recordingText,
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                    color: isRecording
                                        ? Colors.red
                                        : Colors.blue,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                if (isAnalyzing)
                                  const Padding(
                                    padding: EdgeInsets.only(top: 16),
                                    child: CircularProgressIndicator(),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResultsSection() {
    final results = analysisResults!;
    final score = results['overall_score'] as int;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Analysis Results',
              style: Theme.of(
                context,
              ).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.green.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.green,
                      borderRadius: BorderRadius.circular(25),
                    ),
                    child: Center(
                      child: Text(
                        '$score',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Overall Score',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        Text(results['feedback'] as String),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ModeButton extends StatelessWidget {
  final String title;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _ModeButton({
    required this.title,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? Theme.of(context).colorScheme.primary
              : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected
                ? Theme.of(context).colorScheme.primary
                : Colors.grey.shade300,
          ),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: isSelected ? Colors.white : Colors.grey.shade600,
              size: 24,
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.grey.shade700,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
