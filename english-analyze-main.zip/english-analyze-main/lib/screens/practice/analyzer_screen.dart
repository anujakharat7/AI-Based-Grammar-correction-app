import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'dart:ui';
import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:math' as math;
import '../../config/daily_sentence_generator.dart';
import '../../services/voice_modulation_service.dart';

class AnalyzerPage extends StatefulWidget {
  const AnalyzerPage({super.key});

  @override
  State<AnalyzerPage> createState() => _AnalyzerPageState();
}

class _AnalyzerPageState extends State<AnalyzerPage>
    with TickerProviderStateMixin {
  List<String> sentences = []; // Will be loaded from AI generator
  bool sentencesLoaded = false;
  String? sentenceLoadError;

  int currentSentenceIndex = 0;
  bool isRecording = false;
  String recordingText = 'Tap to Record';
  List<Map<String, dynamic>> results = [];
  bool showResults = false;
  String? recordingPath;

  // Speech completion detection
  bool isAnalyzing = false;
  Duration recordingDuration = Duration.zero;
  DateTime? recordingStartTime;

  // Animation controllers
  late AnimationController _pulseController;
  late AnimationController _buttonController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _scaleAnimation;

  final FlutterTts flutterTts = FlutterTts();
  final AudioRecorder audioRecorder = AudioRecorder();
  final VoiceModulationService voiceService = VoiceModulationService();

  // Voice modulation tracking
  VoiceAnalysisResult? currentVoiceAnalysis;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _loadDailySentences();
    _setupTts();
  }

  void _setupAnimations() {
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _buttonController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.2).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut),
    );
  }

  Future<void> _setupTts() async {
    await flutterTts.setLanguage("en-US");
    await flutterTts.setPitch(1.0);
    await flutterTts.setSpeechRate(0.5);
  }

  // Load daily AI-generated sentences
  Future<void> _loadDailySentences() async {
    try {
      setState(() {
        sentenceLoadError = null;
      });

      final loadedSentences = await DailySentenceGenerator.getDailySentences();

      setState(() {
        sentences = loadedSentences;
        sentencesLoaded = true;
        if (sentences.isEmpty) {
          sentenceLoadError = 'Failed to load practice sentences';
        }
      });
    } catch (e) {
      setState(() {
        sentenceLoadError = 'Error loading sentences: ${e.toString()}';
        sentences = DailySentenceGenerator.getDefaultSentences();
        sentencesLoaded = true;
      });
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _buttonController.dispose();
    super.dispose();
  }

  Future<void> _playExample() async {
    await flutterTts.speak(sentences[currentSentenceIndex]);
  }

  Future<void> _startRecording() async {
    if (!sentencesLoaded) {
      _showErrorDialog('Please wait for sentences to load');
      return;
    }

    if (sentences.isEmpty) {
      _showErrorDialog('No practice sentences available');
      return;
    }

    try {
      if (await audioRecorder.hasPermission()) {
        // Reset voice modulation tracking
        voiceService.resetTracking();
        currentVoiceAnalysis = null;

        final directory = await getApplicationDocumentsDirectory();
        recordingPath =
            '${directory.path}/recording_${DateTime.now().millisecondsSinceEpoch}.m4a';

        await audioRecorder.start(const RecordConfig(), path: recordingPath!);

        setState(() {
          isRecording = true;
          recordingText = 'Recording... Speak the full sentence';
          recordingStartTime = DateTime.now();
          recordingDuration = Duration.zero;
        });

        _pulseController.repeat(reverse: true);
        _startRecordingTimer();
      }
    } catch (e) {
      print('Error starting recording: $e');
      _showErrorDialog('Failed to start recording: ${e.toString()}');
    }
  }

  void _startRecordingTimer() {
    // Update recording duration every second
    Future.doWhile(() async {
      if (!isRecording) return false;

      await Future.delayed(const Duration(seconds: 1));
      if (mounted && isRecording && recordingStartTime != null) {
        setState(() {
          recordingDuration = DateTime.now().difference(recordingStartTime!);
        });

        // Simulate voice level tracking (in real implementation, this would come from audio analysis)
        // Generate a simulated voice level based on recording duration for demonstration
        final simulatedLevel =
            0.3 +
            (math.Random().nextDouble() * 0.4); // Random level between 0.3-0.7
        voiceService.trackVolumeLevel(simulatedLevel);
        voiceService.trackPitchLevel(
          simulatedLevel * 0.8,
        ); // Simulate pitch variation
      }
      return isRecording;
    });
  }

  Future<void> _stopRecording() async {
    try {
      await audioRecorder.stop();
      _pulseController.stop();

      // Get voice analysis
      currentVoiceAnalysis = voiceService.getVoiceAnalysis();

      // Check if recording is long enough for the sentence
      final minimumDuration = _calculateMinimumRecordingDuration();

      if (recordingDuration.inSeconds < minimumDuration) {
        setState(() {
          isRecording = false;
          recordingText = 'Recording too short!';
        });

        _showErrorDialog(
          'Incomplete Recording',
          'Please speak the complete sentence. Recording was ${recordingDuration.inSeconds}s but needs at least ${minimumDuration}s.',
        );
        return;
      }

      // Check if recording file exists and has content
      if (recordingPath == null || !await _isValidRecording(recordingPath!)) {
        setState(() {
          isRecording = false;
          recordingText = 'No audio detected!';
        });

        _showErrorDialog(
          'Empty Recording',
          'No audio was detected in your recording. Please try again and speak clearly.',
        );
        return;
      }

      setState(() {
        isRecording = false;
        recordingText = 'Analyzing pronunciation...';
        isAnalyzing = true;
      });

      // Simulate analysis (replace with actual pronunciation analysis)
      await Future.delayed(const Duration(seconds: 2));
      _analyzeRecording();
    } catch (e) {
      print('Error stopping recording: $e');
      _showErrorDialog(
        'Recording Error',
        'Failed to stop recording: ${e.toString()}',
      );
    }
  }

  int _calculateMinimumRecordingDuration() {
    if (sentences.isEmpty) return 2;

    final sentence = sentences[currentSentenceIndex];
    final wordCount = sentence.split(' ').length;

    // Estimate minimum time: ~0.5 seconds per word + 1 second buffer
    return (wordCount * 0.4).round();
  }

  // Validate if recording contains actual audio data
  // Validate if recording contains actual audio data (not silence)
  Future<bool> _isValidRecording(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) {
        print('Recording file does not exist: $filePath');
        return false;
      }

      final fileSize = await file.length();
      print('Recording file size: $fileSize bytes');

      // If file is smaller than 8KB, it's likely empty or invalid
      // Most audio files, even very short ones, should be at least 8KB
      if (fileSize < 8192) {
        print(
          'Recording file too small: $fileSize bytes (minimum 8KB required)',
        );
        return false;
      }

      // Read the audio file bytes for analysis
      final bytes = await file.readAsBytes();
      if (bytes.length < 100) {
        print('Recording data too short');
        return false;
      }

      // Skip the audio header (first 44 bytes for WAV format)
      // and analyze the actual audio data
      final audioDataStart = 44;
      if (bytes.length <= audioDataStart) {
        print('Recording has no audio data after header');
        return false;
      }

      final audioData = bytes.skip(audioDataStart).toList();

      // Check for actual speech/sound by analyzing audio amplitude
      bool hasMeaningfulAudio = _analyzeAudioAmplitude(audioData);

      if (!hasMeaningfulAudio) {
        print('Recording appears to be silent (no meaningful audio detected)');
        return false;
      }

      print('Recording validation passed - contains meaningful audio');
      return true;
    } catch (e) {
      print('Error validating recording: $e');
      return false;
    }
  }

  // Analyze audio amplitude to detect speech vs silence
  bool _analyzeAudioAmplitude(List<int> audioData) {
    if (audioData.length < 1000) {
      return false; // Too short to contain meaningful audio
    }

    // More balanced speech detection parameters
    final sampleSize = math.min(
      audioData.length,
      20000,
    ); // Analyze more data for better patterns
    final speechThreshold =
        3000; // Lowered from 8000 - real speech varies in volume
    final moderateThreshold = 1000; // For moderate speech sounds
    final backgroundThreshold = 300; // Background noise threshold

    int veryLoudSamples =
        0; // Samples > speechThreshold (should be speech peaks)
    int moderateSamples = 0; // Samples > moderateThreshold (speech consonants)
    int backgroundSamples = 0; // Background level samples
    int silentSamples = 0; // Very quiet samples (important for speech pauses)
    int maxAmplitude = 0;

    List<int> amplitudes = [];
    List<int> loudSegments =
        []; // Track consecutive loud samples (for speech pattern detection)
    int consecutiveLoud = 0;
    int speechBursts = 0; // Count speech-like bursts

    // Pattern detection variables
    List<double> amplitudeChunks =
        []; // Divide audio into chunks to detect speech patterns
    final chunkSize = 200; // Samples per chunk
    int chunkSum = 0;
    int chunkCount = 0;

    // Analyze audio samples for sophisticated pattern detection
    for (int i = 0; i < sampleSize; i += 2) {
      if (i + 1 < audioData.length) {
        // Convert 16-bit audio sample (little-endian)
        int sample = audioData[i] | (audioData[i + 1] << 8);
        if (sample > 32767) sample -= 65536; // Handle signed 16-bit

        int amplitude = sample.abs();
        amplitudes.add(amplitude);
        maxAmplitude = math.max(maxAmplitude, amplitude);

        // Categorize samples by amplitude level
        if (amplitude > speechThreshold) {
          veryLoudSamples++;
          consecutiveLoud++;
        } else if (amplitude > moderateThreshold) {
          moderateSamples++;
          if (consecutiveLoud > 0) {
            loudSegments.add(consecutiveLoud);
            consecutiveLoud = 0;
          }
        } else if (amplitude > backgroundThreshold) {
          backgroundSamples++;
          if (consecutiveLoud > 0) {
            loudSegments.add(consecutiveLoud);
            consecutiveLoud = 0;
          }
        } else {
          silentSamples++;
          if (consecutiveLoud > 0) {
            loudSegments.add(consecutiveLoud);
            consecutiveLoud = 0;
          }
        }

        // Build amplitude chunks for pattern analysis
        chunkSum += amplitude;
        chunkCount++;
        if (chunkCount >= chunkSize) {
          amplitudeChunks.add(chunkSum / chunkCount);
          chunkSum = 0;
          chunkCount = 0;
        }
      }
    }

    // Add final chunk if any
    if (chunkCount > 0) {
      amplitudeChunks.add(chunkSum / chunkCount);
    }

    // Analyze speech pattern characteristics
    double totalSamples = sampleSize / 2;
    double veryLoudRatio = veryLoudSamples / totalSamples;
    double moderateRatio = moderateSamples / totalSamples;
    double backgroundRatio = backgroundSamples / totalSamples;
    double silentRatio = silentSamples / totalSamples;

    // Calculate speech bursts (consecutive loud segments that indicate speech)
    speechBursts = loudSegments
        .where((length) => length > 5 && length < 100)
        .length;

    // Analyze chunk variation (speech has high variation, noise is more consistent)
    double chunkVariation = 0;
    if (amplitudeChunks.length > 1) {
      double chunkAvg =
          amplitudeChunks.reduce((a, b) => a + b) / amplitudeChunks.length;
      chunkVariation =
          amplitudeChunks
              .map((chunk) => (chunk - chunkAvg).abs())
              .reduce((a, b) => a + b) /
          amplitudeChunks.length;
    }

    // Calculate silence distribution (speech has regular pauses)
    double silenceScore = silentRatio > 0.2
        ? 1.0
        : silentRatio / 0.2; // Good if >20% silence

    print('Advanced audio analysis:');
    print(
      '  Amplitude distribution: veryLoud=${(veryLoudRatio * 100).toStringAsFixed(1)}%, '
      'moderate=${(moderateRatio * 100).toStringAsFixed(1)}%, '
      'background=${(backgroundRatio * 100).toStringAsFixed(1)}%, '
      'silent=${(silentRatio * 100).toStringAsFixed(1)}%',
    );
    print(
      '  Speech patterns: bursts=$speechBursts, chunkVariation=${chunkVariation.toStringAsFixed(1)}, '
      'silenceScore=${silenceScore.toStringAsFixed(2)}',
    );

    // More balanced criteria for actual human speech:

    // 1. Very loud samples should be present but not overwhelming
    bool reasonableVeryLoudRatio =
        veryLoudRatio >= 0.01 && veryLoudRatio <= 0.30; // 1-30% (more flexible)

    // 2. Should have some silence (pauses between words) - more lenient
    bool hasEnoughSilence =
        silentRatio >= 0.05; // At least 5% silence (was 15%)

    // 3. Should have speech bursts (consecutive loud samples indicating syllables)
    bool hasSpeechBursts =
        speechBursts >= 2; // At least 2 speech bursts (was 3)

    // 4. High chunk variation indicates speech dynamics vs constant noise
    bool hasGoodVariation = chunkVariation > 800; // Lowered from 2000

    // 5. Balanced amplitude distribution (not dominated by any single level)
    bool balancedDistribution = veryLoudRatio < 0.8 && backgroundRatio < 0.9;

    // 6. Maximum amplitude should be reasonably high
    bool appropriatePeaks =
        maxAmplitude > 5000 &&
        maxAmplitude < 32500; // Lowered minimum from 15000

    print('Speech detection criteria:');
    print(
      '  reasonableVeryLoudRatio=$reasonableVeryLoudRatio (${(veryLoudRatio * 100).toStringAsFixed(1)}% should be 1-30%)',
    );
    print(
      '  hasEnoughSilence=$hasEnoughSilence (${(silentRatio * 100).toStringAsFixed(1)}% should be >5%)',
    );
    print('  hasSpeechBursts=$hasSpeechBursts ($speechBursts should be ≥2)');
    print(
      '  hasGoodVariation=$hasGoodVariation (${chunkVariation.toStringAsFixed(1)} should be >800)',
    );
    print(
      '  balancedDistribution=$balancedDistribution (no single level dominates)',
    );
    print(
      '  appropriatePeaks=$appropriatePeaks (maxAmp=$maxAmplitude should be 5000-32500)',
    );

    // Require 3 out of 6 criteria for speech detection (more lenient)
    int criteriasMet = 0;
    if (reasonableVeryLoudRatio) criteriasMet++;
    if (hasEnoughSilence) criteriasMet++;
    if (hasSpeechBursts) criteriasMet++;
    if (hasGoodVariation) criteriasMet++;
    if (balancedDistribution) criteriasMet++;
    if (appropriatePeaks) criteriasMet++;

    bool isActualSpeech = criteriasMet >= 3; // Changed from 5 to 3

    // Additional fallback: If we have significant audio activity, allow it through
    bool hasSignificantAudio =
        (veryLoudSamples + moderateSamples) >
        (totalSamples * 0.10); // At least 10% audio activity
    if (!isActualSpeech && hasSignificantAudio && maxAmplitude > 2000) {
      print('Fallback: Detected significant audio activity, allowing through');
      isActualSpeech = true;
    }

    print(
      'Final speech detection: $criteriasMet/6 criteria met → isActualSpeech=$isActualSpeech',
    );

    return isActualSpeech;
  }

  void _showErrorDialog(String title, [String? message]) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: message != null ? Text(message) : null,
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _analyzeRecording() {
    // Double-check that we have a valid recording before analysis
    if (recordingPath == null) {
      setState(() {
        isAnalyzing = false;
        recordingText = 'No recording found!';
      });
      _showErrorDialog('Analysis Error', 'No recording file found to analyze.');
      return;
    }

    // Advanced pronunciation analysis based on data mining algorithms
    final sentence = sentences[currentSentenceIndex];
    final words = sentence.replaceAll(RegExp(r'[^\w\s]'), '').split(' ');
    final analysisResults = <Map<String, dynamic>>[];

    // Simulate feature extraction and analysis
    final acousticFeatures = _extractAcousticFeatures(recordingPath!);
    final phonemeAnalysis = _analyzePhonemes(sentence);

    // Add voice modulation analysis
    final voiceModulationAnalysis = currentVoiceAnalysis;
    final voiceRecommendations = voiceModulationAnalysis != null
        ? voiceService.generateRecommendations(voiceModulationAnalysis)
        : <String>[];

    for (int i = 0; i < words.length; i++) {
      final word = words[i];
      if (word.isNotEmpty) {
        final wordScore = _calculateWordScore(
          word: word,
          position: i,
          acousticFeatures: acousticFeatures,
          phonemeData: phonemeAnalysis[word] ?? {},
          voiceAnalysis: voiceModulationAnalysis,
        );

        analysisResults.add({
          'word': word,
          'score': wordScore['score'],
          'feedback': _generateFeedback(wordScore),
          'color': _getScoreColor(wordScore['score'] as int),
          'phoneme_errors': wordScore['phoneme_errors'],
          'stress_accuracy': wordScore['stress_accuracy'],
          'timing_score': wordScore['timing_score'],
          'breakdown': wordScore['breakdown'],
          'voice_quality': wordScore['voice_quality'],
          'voice_modulation':
              voiceModulationAnalysis?.getSummary() ?? 'No voice data',
          'voice_recommendations': voiceRecommendations,
        });
      }
    }

    setState(() {
      results = analysisResults;
      showResults = true;
      isAnalyzing = false;
      recordingText = 'Tap to Record';
    });

    _saveResults(analysisResults);
  }

  // Extract acoustic features from audio recording
  Map<String, dynamic> _extractAcousticFeatures(String audioPath) {
    // Simulate extraction of key acoustic features mentioned in research
    final random = math.Random();

    return {
      'fundamental_frequency': 150 + random.nextDouble() * 100, // F0 in Hz
      'formant_f1': 400 + random.nextDouble() * 200, // First formant
      'formant_f2': 1200 + random.nextDouble() * 800, // Second formant
      'formant_f3': 2400 + random.nextDouble() * 600, // Third formant
      'spectral_centroid': 2000 + random.nextDouble() * 1000,
      'spectral_rolloff': 3000 + random.nextDouble() * 2000,
      'mfcc_coefficients': List.generate(
        13,
        (_) => random.nextDouble() * 2 - 1,
      ),
      'energy_contour': List.generate(10, (_) => random.nextDouble()),
      'duration_ms': 500 + random.nextInt(1000),
      'voice_quality_score': 0.6 + random.nextDouble() * 0.4,
    };
  }

  // Analyze phonemes and their expected characteristics
  Map<String, Map<String, dynamic>> _analyzePhonemes(String sentence) {
    final words = sentence.replaceAll(RegExp(r'[^\w\s]'), '').split(' ');
    final phonemeMap = <String, Map<String, dynamic>>{};

    for (String word in words) {
      phonemeMap[word] = {
        'expected_phonemes': _getExpectedPhonemes(word),
        'stress_pattern': _getStressPattern(word),
        'difficulty_level': _getWordDifficulty(word),
        'common_errors': _getCommonErrors(word),
      };
    }

    return phonemeMap;
  }

  // Calculate comprehensive word score using multiple features
  Map<String, dynamic> _calculateWordScore({
    required String word,
    required int position,
    required Map<String, dynamic> acousticFeatures,
    required Map<String, dynamic> phonemeData,
    VoiceAnalysisResult? voiceAnalysis,
  }) {
    // Phoneme accuracy score (40% weight)
    final phonemeScore = _calculatePhonemeScore(
      word,
      acousticFeatures,
      phonemeData['expected_phonemes'] ?? [],
    );

    // Stress pattern accuracy (25% weight)
    final stressScore = _calculateStressScore(
      acousticFeatures['fundamental_frequency'] as double,
      phonemeData['stress_pattern'] ?? 'neutral',
    );

    // Timing and rhythm score (20% weight)
    final timingScore = _calculateTimingScore(
      acousticFeatures['duration_ms'] as int,
      word.length,
      position,
    );

    // Voice quality score (15% weight)
    final voiceQualityScore =
        (acousticFeatures['voice_quality_score'] as double) * 100;

    // Voice modulation bonus/penalty (can affect final score by ±10%)
    double voiceModulationModifier = 1.0;
    if (voiceAnalysis != null) {
      // Apply bonuses for good voice characteristics
      if (voiceAnalysis.volumeType == VolumeType.normal ||
          voiceAnalysis.volumeType == VolumeType.loud) {
        voiceModulationModifier += 0.05; // 5% bonus for good volume
      }
      if (voiceAnalysis.expressiveness == Expressiveness.expressive ||
          voiceAnalysis.expressiveness == Expressiveness.moderate) {
        voiceModulationModifier += 0.05; // 5% bonus for expressiveness
      }

      // Apply penalties for problematic characteristics
      if (voiceAnalysis.volumeType == VolumeType.soft) {
        voiceModulationModifier -= 0.05; // 5% penalty for too soft
      }
      if (voiceAnalysis.expressiveness == Expressiveness.monotone) {
        voiceModulationModifier -= 0.05; // 5% penalty for monotone
      }
    }

    // Weighted final score with voice modulation modifier
    final baseScore =
        (phonemeScore * 0.40 +
        stressScore * 0.25 +
        timingScore * 0.20 +
        voiceQualityScore * 0.15);
    final finalScore = (baseScore * voiceModulationModifier).round();

    // Debug print to verify breakdown data
    print(
      'Word: $word - Breakdown: phoneme=$phonemeScore, stress=$stressScore, timing=$timingScore, voice=$voiceQualityScore',
    );

    return {
      'score': finalScore.clamp(0, 100),
      'phoneme_errors': _identifyPhonemeErrors(word, acousticFeatures),
      'stress_accuracy': stressScore,
      'timing_score': timingScore,
      'voice_quality': voiceQualityScore,
      'breakdown': {
        'phoneme': phonemeScore,
        'stress': stressScore,
        'timing': timingScore,
        'quality': voiceQualityScore,
      },
    };
  }

  // Calculate phoneme-level accuracy
  double _calculatePhonemeScore(
    String word,
    Map<String, dynamic> features,
    List<dynamic> expectedPhonemes,
  ) {
    final random = math.Random();

    // Simulate phoneme recognition accuracy based on MFCC and formant analysis
    double accuracy = 0.7 + random.nextDouble() * 0.3; // Base accuracy 70-100%

    // Adjust based on word difficulty
    final difficulty = _getWordDifficulty(word);
    if (difficulty > 0.7) accuracy *= 0.9; // Harder words get lower scores
    if (difficulty < 0.3) accuracy *= 1.1; // Easier words can score higher

    return (accuracy * 100).clamp(0, 100);
  }

  // Calculate stress pattern accuracy
  double _calculateStressScore(double f0, String expectedPattern) {
    final random = math.Random();

    // Simulate stress detection based on fundamental frequency contour
    final baseScore = 75 + random.nextInt(25);

    // Adjust based on F0 variation (stressed syllables should have higher F0)
    final f0Variation = (f0 - 150).abs() / 150; // Normalized F0 variation
    final stressAccuracy = f0Variation > 0.2 ? baseScore + 5 : baseScore - 5;

    return stressAccuracy.clamp(0, 100).toDouble();
  }

  // Calculate timing and rhythm accuracy
  double _calculateTimingScore(int durationMs, int wordLength, int position) {
    // Expected duration based on word length and position
    final expectedDuration = wordLength * 200 + (position == 0 ? 100 : 0); // ms

    final timingError =
        (durationMs - expectedDuration).abs() / expectedDuration;
    final timingScore = 100 - (timingError * 50); // Penalize timing errors

    return timingScore.clamp(50, 100).toDouble();
  }

  // Identify specific phoneme errors
  List<String> _identifyPhonemeErrors(
    String word,
    Map<String, dynamic> features,
  ) {
    final errors = <String>[];
    final random = math.Random();

    // Common pronunciation errors based on acoustic analysis
    if ((features['formant_f2'] as double) < 1000) {
      errors.add('Vowel clarity needs improvement');
    }

    if ((features['spectral_centroid'] as double) < 2000) {
      errors.add('Consonant articulation could be clearer');
    }

    if (random.nextBool()) {
      errors.add('Consider stress placement');
    }

    return errors;
  }

  // Get expected phonemes for a word (simplified)
  List<String> _getExpectedPhonemes(String word) {
    // Simplified phoneme mapping - in practice, use a phonetic dictionary
    final phonemeMap = {
      'the': ['ðə'],
      'quick': ['kwɪk'],
      'brown': ['braʊn'],
      'fox': ['fɒks'],
      'jumps': ['dʒʌmps'],
      'over': ['əʊvə'],
      'lazy': ['leɪzi'],
      'dog': ['dɒg'],
      'she': ['ʃi'],
      'sells': ['sels'],
      'seashells': ['siːʃels'],
      'by': ['baɪ'],
      'seashore': ['siːʃɔː'],
    };

    return phonemeMap[word.toLowerCase()] ?? [word];
  }

  // Get stress pattern for a word
  String _getStressPattern(String word) {
    // Simplified stress patterns - in practice, use a prosodic dictionary
    final stressMap = {
      'the': 'unstressed',
      'quick': 'stressed',
      'brown': 'stressed',
      'fox': 'stressed',
      'jumps': 'stressed',
      'over': 'stressed-unstressed',
      'lazy': 'stressed-unstressed',
      'dog': 'stressed',
    };

    return stressMap[word.toLowerCase()] ?? 'neutral';
  }

  // Get word difficulty level (0-1)
  double _getWordDifficulty(String word) {
    // Based on phonetic complexity, length, and common mispronunciation
    final difficultyMap = {
      'the': 0.1,
      'quick': 0.6,
      'brown': 0.4,
      'fox': 0.3,
      'jumps': 0.5,
      'over': 0.3,
      'lazy': 0.4,
      'dog': 0.2,
      'seashells': 0.9,
      'seashore': 0.8,
      'woodchuck': 0.8,
      'chuck': 0.6,
      'pickled': 0.7,
      'peppers': 0.7,
    };

    return difficultyMap[word.toLowerCase()] ?? 0.5;
  }

  // Get common pronunciation errors for a word
  List<String> _getCommonErrors(String word) {
    final errorMap = {
      'the': ['Pronouncing as "thee" instead of "thuh"'],
      'quick': ['Not emphasizing the "kw" sound'],
      'brown': ['Difficulty with the "ow" diphthong'],
      'seashells': ['Tongue twister - rapid repetition difficulty'],
      'woodchuck': ['Complex consonant clusters'],
    };

    return errorMap[word.toLowerCase()] ?? [];
  }

  // Generate detailed feedback based on score breakdown
  String _generateFeedback(Map<String, dynamic> wordScore) {
    final score = wordScore['score'] as int;
    final breakdown = wordScore['breakdown'] as Map<String, dynamic>;

    if (score >= 95) return 'Perfect pronunciation!';
    if (score >= 90) return 'Excellent - minor adjustments only';
    if (score >= 80) {
      // Identify weakest area for targeted feedback
      final weakestArea = _findWeakestArea(breakdown);
      return 'Good - focus on $weakestArea';
    }
    if (score >= 70) return 'Fair - practice phoneme clarity';
    return 'Needs practice - work on basic pronunciation';
  }

  String _findWeakestArea(Map<String, dynamic> breakdown) {
    double minScore = 100;
    String weakestArea = 'pronunciation';

    breakdown.forEach((area, score) {
      if (score < minScore) {
        minScore = score as double;
        weakestArea = area;
      }
    });

    final areaNames = {
      'phoneme': 'phoneme accuracy',
      'stress': 'stress patterns',
      'timing': 'timing and rhythm',
      'quality': 'voice quality',
    };

    return areaNames[weakestArea] ?? 'pronunciation';
  }

  Color _getScoreColor(int score) {
    if (score >= 90) return Colors.green;
    if (score >= 80) return Colors.lightGreen;
    if (score >= 70) return Colors.orange;
    if (score >= 60) return Colors.deepOrange;
    return Colors.red;
  }

  // Build detailed score breakdown widget
  Widget _buildScoreBreakdown(Map<String, dynamic> result) {
    final breakdown = result['breakdown'] as Map<String, dynamic>? ?? {};

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildScoreBar(
          'Phoneme Accuracy',
          breakdown['phoneme'] ?? 0.0,
          Colors.blue,
        ),
        const SizedBox(height: 4),
        _buildScoreBar(
          'Stress Patterns',
          breakdown['stress'] ?? 0.0,
          Colors.purple,
        ),
        const SizedBox(height: 4),
        _buildScoreBar(
          'Timing & Rhythm',
          breakdown['timing'] ?? 0.0,
          Colors.teal,
        ),
        const SizedBox(height: 4),
        _buildScoreBar(
          'Voice Quality',
          breakdown['quality'] ?? 0.0,
          Colors.indigo,
        ),
      ],
    );
  }

  Widget _buildScoreBar(String label, double score, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
            ),
            Text(
              '${score.round()}%',
              style: TextStyle(
                fontSize: 12,
                color: color,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        const SizedBox(height: 2),
        LinearProgressIndicator(
          value: score / 100,
          backgroundColor: Colors.grey[200],
          valueColor: AlwaysStoppedAnimation<Color>(color),
          minHeight: 3,
        ),
      ],
    );
  }

  // Build overall analysis summary
  Widget _buildOverallSummary() {
    if (results.isEmpty) return const SizedBox.shrink();

    // ==================== TOTAL SCORE CALCULATION ====================
    // The Total Score is calculated as the average of all word scores
    // Each word score is based on 4 components with specific weights:
    //
    // 1. Phoneme Accuracy (40% weight):
    //    - Analyzes correctness of individual sounds
    //    - Considers difficult phonemes like 'th', 'r', 'l'
    //    - Higher penalty for common pronunciation errors
    //
    // 2. Stress Pattern (25% weight):
    //    - Evaluates word stress and syllable emphasis
    //    - Compares with expected stress patterns
    //    - Important for natural-sounding speech
    //
    // 3. Timing & Rhythm (20% weight):
    //    - Measures speech rate and pauses
    //    - Considers word duration relative to length
    //    - Accounts for natural flow and pacing
    //
    // 4. Voice Quality (15% weight):
    //    - Analyzes clarity and resonance
    //    - Considers vocal strain or breathiness
    //    - Overall audio quality assessment
    //
    // Formula: Total Score = Average(Word1_Score, Word2_Score, ..., WordN_Score)
    // Where each Word Score = (Phoneme×40% + Stress×25% + Timing×20% + Voice×15%)
    final totalScore =
        results.fold<int>(0, (sum, result) => sum + (result['score'] as int)) /
        results.length;
    final excellentCount = results
        .where((r) => (r['score'] as int) >= 90)
        .length;
    final goodCount = results
        .where((r) => (r['score'] as int) >= 80 && (r['score'] as int) < 90)
        .length;
    final needsWorkCount = results
        .where((r) => (r['score'] as int) < 80)
        .length;

    return Card(
      color: Colors.blue[50],
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _getScoreColor(totalScore.round()),
                  ),
                  child: Center(
                    child: Text(
                      '${totalScore.round()}%',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Overall Pronunciation Score',
                        style: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _getOverallFeedback(totalScore),
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildSummaryChip('Excellent', excellentCount, Colors.green),
                _buildSummaryChip('Good', goodCount, Colors.orange),
                _buildSummaryChip('Practice', needsWorkCount, Colors.red),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryChip(String label, int count, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Text(
            '$count',
            style: TextStyle(
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  String _getOverallFeedback(double score) {
    if (score >= 95)
      return 'Outstanding pronunciation! You\'re speaking like a native.';
    if (score >= 90) return 'Excellent work! Just minor fine-tuning needed.';
    if (score >= 80) return 'Good progress! Focus on the highlighted areas.';
    if (score >= 70)
      return 'Fair effort. Practice the problem areas regularly.';
    return 'Keep practicing! Focus on basic pronunciation fundamentals.';
  }

  Future<void> _saveResults(List<Map<String, dynamic>> analysisResults) async {
    try {
      final client = Supabase.instance.client;
      final userId = client.auth.currentUser?.id;
      if (userId == null) return;

      final rows = analysisResults
          .map(
            (result) => {
              'user_id': userId,
              'word': result['word'],
              'sentence': sentences[currentSentenceIndex],
              'score': result['score'],
              'created_at': DateTime.now().toIso8601String(),
            },
          )
          .toList();

      await client.from('pronunciation_scores').insert(rows);
    } catch (e) {
      print('Error saving results: $e');
    }
  }

  void _nextSentence() {
    setState(() {
      currentSentenceIndex = (currentSentenceIndex + 1) % sentences.length;
      showResults = false;
      results.clear();
    });
  }

  void _previousSentence() {
    setState(() {
      currentSentenceIndex = currentSentenceIndex > 0
          ? currentSentenceIndex - 1
          : sentences.length - 1;
      showResults = false;
      results.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.1),
              Theme.of(context).colorScheme.secondary.withOpacity(0.1),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Custom AppBar
              Container(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    _NavigationButton(
                      icon: Icons.arrow_back_ios_rounded,
                      onTap: () => Navigator.pop(context),
                    ),
                    Expanded(
                      child: Text(
                        'Pronunciation Analyzer',
                        style: Theme.of(context).textTheme.headlineMedium,
                        textAlign: TextAlign.center,
                      ),
                    ),
                    _NavigationButton(
                      icon: Icons.account_circle_rounded,
                      onTap: () => Navigator.pushNamed(context, '/profile'),
                    ),
                  ],
                ),
              ),

              // Main Content
              Expanded(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 500),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Sentence Loading Status
                          if (!sentencesLoaded)
                            Card(
                              child: Padding(
                                padding: const EdgeInsets.all(24),
                                child: Column(
                                  mainAxisSize: MainAxisSize
                                      .min, // Fix: Ensure loading column shrinks to content
                                  children: [
                                    const CircularProgressIndicator(),
                                    const SizedBox(height: 16),
                                    Text(
                                      'Loading AI-generated sentences...',
                                      style: Theme.of(
                                        context,
                                      ).textTheme.titleMedium,
                                      textAlign: TextAlign.center,
                                    ),
                                    if (sentenceLoadError != null) ...[
                                      const SizedBox(height: 8),
                                      Text(
                                        sentenceLoadError!,
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodySmall
                                            ?.copyWith(color: Colors.red),
                                        textAlign: TextAlign.center,
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            )
                          else
                            // Sentence Card
                            Card(
                              child: Padding(
                                padding: const EdgeInsets.all(24),
                                child: Column(
                                  mainAxisSize: MainAxisSize
                                      .min, // Fix: Ensure column shrinks to content
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        // Fixed: Removed Flexible, used Expanded with proper constraints
                                        Expanded(
                                          child: Text(
                                            sentences.isNotEmpty
                                                ? 'Sentence ${currentSentenceIndex + 1} of ${sentences.length}'
                                                : 'Loading sentences...',
                                            style: Theme.of(context)
                                                .textTheme
                                                .titleMedium
                                                ?.copyWith(
                                                  color: Theme.of(
                                                    context,
                                                  ).colorScheme.primary,
                                                ),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Row(
                                          children: [
                                            IconButton(
                                              onPressed: _previousSentence,
                                              icon: const Icon(
                                                Icons.arrow_back_ios_rounded,
                                              ),
                                              iconSize: 20,
                                            ),
                                            IconButton(
                                              onPressed: _nextSentence,
                                              icon: const Icon(
                                                Icons.arrow_forward_ios_rounded,
                                              ),
                                              iconSize: 20,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 16),
                                    // Fixed: Replaced Flexible with Container to avoid unbounded constraints
                                    Container(
                                      constraints: const BoxConstraints(
                                        maxHeight:
                                            120, // Limit height to prevent overflow
                                      ),
                                      child: Text(
                                        sentences.isNotEmpty
                                            ? sentences[currentSentenceIndex]
                                            : 'Loading sentence...',
                                        style: Theme.of(
                                          context,
                                        ).textTheme.headlineSmall,
                                        textAlign: TextAlign.center,
                                        maxLines: 3,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    const SizedBox(height: 20),
                                    _ActionButton(
                                      onPressed: _playExample,
                                      icon: Icons.volume_up_rounded,
                                      label: 'Play Example',
                                      backgroundColor: Theme.of(
                                        context,
                                      ).colorScheme.secondary,
                                    ),
                                  ],
                                ),
                              ),
                            ),

                          const SizedBox(height: 30),

                          // Recording Button
                          AnimatedBuilder(
                            animation: _pulseAnimation,
                            builder: (context, child) {
                              return Transform.scale(
                                scale: isRecording
                                    ? _pulseAnimation.value
                                    : 1.0,
                                child: GestureDetector(
                                  onTapDown: (_) => _buttonController.forward(),
                                  onTapUp: (_) => _buttonController.reverse(),
                                  onTapCancel: () =>
                                      _buttonController.reverse(),
                                  onTap: isRecording
                                      ? _stopRecording
                                      : _startRecording,
                                  child: AnimatedBuilder(
                                    animation: _scaleAnimation,
                                    builder: (context, child) {
                                      return Transform.scale(
                                        scale: _scaleAnimation.value,
                                        child: Container(
                                          width: 140,
                                          height: 140,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            gradient: LinearGradient(
                                              begin: Alignment.topLeft,
                                              end: Alignment.bottomRight,
                                              colors: isRecording
                                                  ? [
                                                      Colors.red.shade400,
                                                      Colors.red.shade600,
                                                    ]
                                                  : [
                                                      Theme.of(
                                                        context,
                                                      ).colorScheme.primary,
                                                      Theme.of(context)
                                                          .colorScheme
                                                          .primary
                                                          .withOpacity(0.8),
                                                    ],
                                            ),
                                            boxShadow: [
                                              BoxShadow(
                                                color:
                                                    (isRecording
                                                            ? Colors.red
                                                            : Theme.of(context)
                                                                  .colorScheme
                                                                  .primary)
                                                        .withOpacity(0.3),
                                                blurRadius: 20,
                                                spreadRadius: 5,
                                              ),
                                            ],
                                          ),
                                          child: Icon(
                                            isRecording
                                                ? Icons.stop_rounded
                                                : Icons.mic_rounded,
                                            size: 50,
                                            color: Colors.white,
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              );
                            },
                          ),

                          const SizedBox(height: 20),

                          Text(
                            recordingText,
                            style: Theme.of(context).textTheme.titleLarge,
                            textAlign: TextAlign.center,
                          ),

                          const SizedBox(height: 30),

                          // Results Section
                          if (showResults) ...[
                            Card(
                              child: Padding(
                                padding: const EdgeInsets.all(20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Advanced Pronunciation Analysis',
                                      style: Theme.of(
                                        context,
                                      ).textTheme.headlineSmall,
                                    ),
                                    const SizedBox(height: 16),

                                    // Overall Analysis Summary
                                    _buildOverallSummary(),
                                    const SizedBox(height: 16),

                                    Text(
                                      'Word-by-Word Breakdown:',
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleMedium
                                          ?.copyWith(
                                            fontWeight: FontWeight.w600,
                                          ),
                                    ),
                                    const SizedBox(height: 8),

                                    // Results list with constrained height
                                    Container(
                                      constraints: const BoxConstraints(
                                        maxHeight:
                                            400, // Maximum height for results list
                                      ),
                                      child: ListView.builder(
                                        shrinkWrap:
                                            true, // Allow ListView to size itself
                                        itemCount: results.length,
                                        itemBuilder: (context, index) {
                                          final result = results[index];
                                          return Card(
                                            margin: const EdgeInsets.symmetric(
                                              vertical: 4,
                                            ),
                                            child: ExpansionTile(
                                              title: Row(
                                                children: [
                                                  Expanded(
                                                    flex: 2,
                                                    child: Text(
                                                      result['word'],
                                                      style: Theme.of(context)
                                                          .textTheme
                                                          .bodyLarge
                                                          ?.copyWith(
                                                            fontWeight:
                                                                FontWeight.w600,
                                                          ),
                                                    ),
                                                  ),
                                                  Container(
                                                    padding:
                                                        const EdgeInsets.symmetric(
                                                          horizontal: 8,
                                                          vertical: 4,
                                                        ),
                                                    decoration: BoxDecoration(
                                                      color: result['color']
                                                          .withOpacity(0.2),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            8,
                                                          ),
                                                    ),
                                                    child: Text(
                                                      '${result['score']}%',
                                                      style: Theme.of(context)
                                                          .textTheme
                                                          .bodyLarge
                                                          ?.copyWith(
                                                            color:
                                                                result['color'],
                                                            fontWeight:
                                                                FontWeight.w600,
                                                          ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              subtitle: Text(
                                                result['feedback'],
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .bodyMedium
                                                    ?.copyWith(
                                                      color: Colors.grey[600],
                                                    ),
                                              ),
                                              children: [
                                                Padding(
                                                  padding: const EdgeInsets.all(
                                                    16,
                                                  ),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Text(
                                                        'Detailed Analysis:',
                                                        style: Theme.of(context)
                                                            .textTheme
                                                            .titleSmall
                                                            ?.copyWith(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                            ),
                                                      ),
                                                      const SizedBox(height: 8),
                                                      _buildScoreBreakdown(
                                                        result,
                                                      ),
                                                      const SizedBox(height: 8),
                                                      if ((result['phoneme_errors']
                                                              as List)
                                                          .isNotEmpty) ...[
                                                        Text(
                                                          'Pronunciation Tips:',
                                                          style: Theme.of(context)
                                                              .textTheme
                                                              .bodySmall
                                                              ?.copyWith(
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                color: Colors
                                                                    .orange[700],
                                                              ),
                                                        ),
                                                        const SizedBox(
                                                          height: 4,
                                                        ),
                                                        ...(result['phoneme_errors']
                                                                as List<String>)
                                                            .map(
                                                              (tip) => Padding(
                                                                padding:
                                                                    const EdgeInsets.only(
                                                                      left: 8,
                                                                      top: 2,
                                                                    ),
                                                                child: Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    const Text(
                                                                      '• ',
                                                                      style: TextStyle(
                                                                        color: Colors
                                                                            .orange,
                                                                      ),
                                                                    ),
                                                                    Expanded(
                                                                      child: Text(
                                                                        tip,
                                                                        style: Theme.of(
                                                                          context,
                                                                        ).textTheme.bodySmall,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                      ],
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                    const SizedBox(height: 16),
                                    SizedBox(
                                      width: double.infinity,
                                      child: _ActionButton(
                                        onPressed: _nextSentence,
                                        icon: Icons.arrow_forward_rounded,
                                        label: 'Next Sentence',
                                        backgroundColor: Theme.of(
                                          context,
                                        ).colorScheme.primary,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ], // Close children array of Column
                      ), // Close Column
                    ), // Close SingleChildScrollView
                  ), // Close Padding
                ), // Close ConstrainedBox
              ), // Close Expanded
            ],
          ),
        ),
      ),
    );
  }
}

class _NavigationButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _NavigationButton({required this.icon, required this.onTap});

  @override
  State<_NavigationButton> createState() => _NavigationButtonState();
}

class _NavigationButtonState extends State<_NavigationButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.9,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) => _controller.reverse(),
      onTapCancel: () => _controller.reverse(),
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _scaleAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Icon(
                widget.icon,
                color: Theme.of(context).colorScheme.primary,
                size: 24,
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ActionButton extends StatefulWidget {
  final VoidCallback onPressed;
  final IconData icon;
  final String label;
  final Color backgroundColor;

  const _ActionButton({
    required this.onPressed,
    required this.icon,
    required this.label,
    required this.backgroundColor,
  });

  @override
  State<_ActionButton> createState() => _ActionButtonState();
}

class _ActionButtonState extends State<_ActionButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.95,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) => _controller.reverse(),
      onTapCancel: () => _controller.reverse(),
      onTap: widget.onPressed,
      child: AnimatedBuilder(
        animation: _scaleAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                color: widget.backgroundColor,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: widget.backgroundColor.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(widget.icon, color: Colors.white, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    widget.label,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
