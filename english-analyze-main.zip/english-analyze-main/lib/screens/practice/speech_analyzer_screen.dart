import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../../config/api_config.dart';
import '../../services/voice_modulation_service.dart';

/// Speech Analyzer Screen - Provides pronunciation analysis for user speech
class SpeechAnalyzer extends StatefulWidget {
  const SpeechAnalyzer({super.key});

  @override
  State<SpeechAnalyzer> createState() => _SpeechAnalyzerState();
}

class _SpeechAnalyzerState extends State<SpeechAnalyzer> {
  final SpeechToText _speechToText = SpeechToText();
  final VoiceModulationService _voiceService = VoiceModulationService();
  GenerativeModel? _geminiModel;

  bool _isListening = false;
  bool _speechEnabled = false;
  String _transcribedText = '';
  String _confidence = '';

  // Current voice analysis result
  VoiceAnalysisResult? _currentVoiceAnalysis;

  @override
  void initState() {
    super.initState();
    _initializeSpeech();
    _initializeGemini();
  }

  @override
  void dispose() {
    _speechToText.stop();
    super.dispose();
  }

  /// Initialize speech recognition
  Future<void> _initializeSpeech() async {
    _speechEnabled = await _speechToText.initialize(
      onError: (errorNotification) {
        debugPrint('Speech recognition error: ${errorNotification.errorMsg}');
        setState(() => _isListening = false);
      },
      onStatus: (status) {
        debugPrint('Speech recognition status: $status');
        if (status == 'done' || status == 'notListening') {
          setState(() => _isListening = false);
          if (_transcribedText.isNotEmpty) {
            _processTranscription(_transcribedText);
          }
        }
      },
    );

    if (!_speechEnabled) {
      _showErrorDialog(
        'Speech Recognition Not Available',
        'Speech recognition is not available on this device.',
      );
    }
  }

  /// Initialize Gemini AI model for speech analysis
  Future<void> _initializeGemini() async {
    if (!ApiConfig.isGeminiConfigured) {
      debugPrint('Gemini API not configured');
      return;
    }

    try {
      _geminiModel = GenerativeModel(
        model: 'gemini-1.5-flash',
        apiKey: ApiConfig.geminiApiKey,
      );
      debugPrint('Gemini initialized successfully');
    } catch (e) {
      debugPrint('Error initializing Gemini: $e');
    }
  }

  /// Start speech recognition
  Future<void> _startListening() async {
    if (!_speechEnabled) {
      _showErrorDialog(
        'Speech Recognition Not Available',
        'Please check your device permissions and internet connection.',
      );
      return;
    }

    setState(() {
      _transcribedText = '';
      _confidence = '';
      _isListening = true;
      // Reset voice modulation tracking
      _voiceService.resetTracking();
      _currentVoiceAnalysis = null;
    });

    await _speechToText.listen(
      onResult: (result) {
        setState(() {
          _transcribedText = result.recognizedWords;
          _confidence = result.hasConfidenceRating
              ? (result.confidence * 100).toStringAsFixed(1)
              : '';
        });
        debugPrint(
          'Speech result: $_transcribedText (confidence: $_confidence%)',
        );
      },
      onSoundLevelChange: (level) {
        // Track sound levels for voice modulation analysis using new service
        _voiceService.trackVolumeLevel(level);
        _voiceService.trackPitchLevel(level * 0.8); // Simulate pitch variation
      },
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      listenOptions: SpeechListenOptions(
        partialResults: true,
        cancelOnError: true,
      ),
      localeId: 'en_US',
    );
  }

  /// Stop speech recognition
  Future<void> _stopListening() async {
    await _speechToText.stop();
    setState(() => _isListening = false);

    // Generate voice modulation analysis using new service
    _currentVoiceAnalysis = _voiceService.getVoiceAnalysis();

    if (_transcribedText.isNotEmpty) {
      await _processTranscription(_transcribedText);
    } else {
      _showErrorDialog(
        'No Speech Detected',
        'We couldn\'t hear any speech. Please try again and speak clearly.',
      );
    }
  }

  /// Process the transcribed text for pronunciation analysis
  Future<void> _processTranscription(String transcription) async {
    if (!ApiConfig.isGeminiConfigured || _geminiModel == null) {
      _showBasicTranscription(transcription);
      return;
    }

    try {
      // Show analysis loading
      _showLoadingDialog('Analyzing pronunciation of: "$transcription"');

      // Analyze pronunciation using Gemini
      final analysis = await _analyzePronunciation(transcription);

      Navigator.of(context).pop(); // Hide loading

      // Show results
      if (analysis != null && analysis.isNotEmpty) {
        _showAnalysisResults(transcription, analysis);
      } else {
        _showBasicTranscription(transcription);
      }
    } catch (e) {
      Navigator.of(context, rootNavigator: true).pop(); // Hide loading
      debugPrint('Error processing transcription: $e');
      _showErrorDialog('Analysis Error', 'Failed to analyze your speech: $e');
    }
  }

  /// Analyze pronunciation using Gemini AI
  Future<String?> _analyzePronunciation(String transcribedText) async {
    final prompt =
        '''
You are an expert English pronunciation and voice modulation analyst. The user spoke this text:

"$transcribedText"

Voice Modulation Data:
${_currentVoiceAnalysis?.getSummary() ?? 'No voice analysis available'}

Based on their speech patterns and voice characteristics, provide a comprehensive assessment:

SCORING CRITERIA:
- Consonant clarity (th, r, l, s, z sounds)
- Vowel accuracy and distinction  
- Word stress patterns
- Overall fluency and rhythm
- Voice modulation (pitch variation, volume control, tone)
- Speaking pace and pauses
- Common non-native pronunciation challenges

Format your response EXACTLY like this:

SCORE: [number from 0-100]/100
TRANSCRIPTION: $transcribedText
WORD_ANALYSIS:
- [word1]: [Good/Fair/Poor] - [brief reason if Fair/Poor]
- [word2]: [Good/Fair/Poor] - [brief reason if Fair/Poor]
VOICE_MODULATION:
- Pitch Variation: [Excellent/Good/Fair/Poor] - [brief explanation]
- Volume Control: [Excellent/Good/Fair/Poor] - [brief explanation]  
- Speaking Tone: [Excellent/Good/Fair/Poor] - [brief explanation]
ISSUES: [Main pronunciation and voice problems detected]
TIPS: [3-4 specific improvement suggestions including voice modulation tips]

Example:
SCORE: 85/100
TRANSCRIPTION: Hello how are you today
WORD_ANALYSIS:
- Hello: Good
- how: Fair - weak 'h' sound
- are: Good  
- you: Good
- today: Good
VOICE_MODULATION:
- Pitch Variation: Good - Nice variation in tone, could be more dynamic
- Volume Control: Fair - Generally consistent but could project more
- Speaking Tone: Good - Natural and conversational
ISSUES: Weak initial consonants, could improve volume projection
TIPS: Practice stronger consonant sounds, project voice more confidently, add more pitch variation for emphasis, slow down slightly for clarity
''';

    return await _callGeminiWithFallback(prompt);
  }

  /// Call Gemini AI with fallback to different models
  Future<String?> _callGeminiWithFallback(String prompt) async {
    final modelNames = ['gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-pro'];

    for (int i = 0; i < modelNames.length; i++) {
      try {
        final model = GenerativeModel(
          model: modelNames[i],
          apiKey: ApiConfig.geminiApiKey,
        );

        final content = [Content.text(prompt)];
        final response = await model.generateContent(content);

        if (response.text != null && response.text!.isNotEmpty) {
          return _cleanText(response.text!);
        }
      } catch (e) {
        debugPrint('Error with model ${modelNames[i]}: $e');
        if (i == modelNames.length - 1) {
          debugPrint('All models failed');
        }
      }
    }

    return null;
  }

  /// Clean up text response from AI
  String _cleanText(String text) {
    // Remove surrounding quotes
    if (text.startsWith('"') && text.endsWith('"')) {
      text = text.substring(1, text.length - 1);
    }
    if (text.startsWith("'") && text.endsWith("'")) {
      text = text.substring(1, text.length - 1);
    }
    return text.replaceAll(RegExp(r'\n+'), ' ').trim();
  }

  /// Parse analysis results into structured format
  Map<String, String> _parseAnalysis(String analysis) {
    final result = <String, String>{};

    try {
      // Extract score
      final scoreMatch = RegExp(
        r'SCORE:\s*(\d+(?:\.\d+)?)/100',
        caseSensitive: false,
      ).firstMatch(analysis);
      result['score'] = scoreMatch?.group(1) ?? 'N/A';

      // Extract transcription
      final transcriptionMatch = RegExp(
        r'TRANSCRIPTION:\s*(.+?)(?=\n|\r|WORD_ANALYSIS|$)',
        caseSensitive: false,
        dotAll: true,
      ).firstMatch(analysis);
      result['transcription'] = transcriptionMatch?.group(1)?.trim() ?? 'N/A';

      // Extract word analysis
      final wordAnalysisMatch = RegExp(
        r'WORD_ANALYSIS:\s*(.+?)(?=\n|\r|VOICE_MODULATION|ISSUES|$)',
        caseSensitive: false,
        dotAll: true,
      ).firstMatch(analysis);
      result['wordAnalysis'] = wordAnalysisMatch?.group(1)?.trim() ?? 'N/A';

      // Extract voice modulation analysis
      final voiceModulationMatch = RegExp(
        r'VOICE_MODULATION:\s*(.+?)(?=\n|\r|ISSUES|$)',
        caseSensitive: false,
        dotAll: true,
      ).firstMatch(analysis);
      result['voiceModulation'] =
          voiceModulationMatch?.group(1)?.trim() ?? 'N/A';

      // Extract issues
      final issuesMatch = RegExp(
        r'ISSUES:\s*(.+?)(?=\n|\r|TIPS|$)',
        caseSensitive: false,
        dotAll: true,
      ).firstMatch(analysis);
      result['issues'] = issuesMatch?.group(1)?.trim() ?? 'N/A';

      // Extract tips
      final tipsMatch = RegExp(
        r'TIPS:\s*(.+?)$',
        caseSensitive: false,
        dotAll: true,
      ).firstMatch(analysis);
      result['tips'] = tipsMatch?.group(1)?.trim() ?? 'N/A';
    } catch (e) {
      debugPrint('Error parsing analysis: $e');
    }

    return result;
  }

  /// Show detailed analysis results in a dialog
  void _showAnalysisResults(String transcription, String analysis) {
    final parsedResults = _parseAnalysis(analysis);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.analytics, color: Colors.blue),
            const SizedBox(width: 8),
            const Text('Pronunciation Analysis'),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildScoreSection(parsedResults['score'] ?? 'N/A'),
              const SizedBox(height: 16),
              _buildSection(
                'What You Said',
                parsedResults['transcription'] ?? transcription,
                Colors.blue,
              ),
              const SizedBox(height: 12),
              _buildSection(
                'Word Analysis',
                parsedResults['wordAnalysis'] ?? 'N/A',
                Colors.green,
              ),
              const SizedBox(height: 12),
              _buildSection(
                'Voice Modulation',
                parsedResults['voiceModulation'] ?? 'N/A',
                Colors.purple,
              ),
              const SizedBox(height: 12),
              _buildSection(
                'Issues Found',
                parsedResults['issues'] ?? 'None detected',
                Colors.orange,
              ),
              const SizedBox(height: 12),
              _buildSection(
                'Improvement Tips',
                parsedResults['tips'] ?? 'Keep practicing!',
                Colors.blue,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _resetForNewRecording();
            },
            child: const Text('Record Again'),
          ),
        ],
      ),
    );
  }

  /// Build score display section
  Widget _buildScoreSection(String score) {
    final scoreValue = double.tryParse(score) ?? 0;
    Color scoreColor = Colors.red;
    String scoreLabel = 'Needs Work';

    if (scoreValue >= 80) {
      scoreColor = Colors.green;
      scoreLabel = 'Excellent';
    } else if (scoreValue >= 60) {
      scoreColor = Colors.orange;
      scoreLabel = 'Good';
    } else if (scoreValue >= 40) {
      scoreColor = Colors.yellow[700]!;
      scoreLabel = 'Fair';
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [scoreColor.withOpacity(0.1), scoreColor.withOpacity(0.05)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: scoreColor.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Pronunciation Score',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                scoreLabel,
                style: TextStyle(
                  fontSize: 16,
                  color: scoreColor,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          Text(
            '$score/100',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: scoreColor,
            ),
          ),
        ],
      ),
    );
  }

  /// Build a section widget for analysis results
  Widget _buildSection(String title, String content, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 4,
              height: 20,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.05),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: color.withOpacity(0.2)),
          ),
          child: Text(
            content,
            style: const TextStyle(fontSize: 14, height: 1.4),
          ),
        ),
      ],
    );
  }

  /// Show basic transcription when analysis fails
  void _showBasicTranscription(String transcription) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Speech Transcribed'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('You said:'),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(transcription, style: const TextStyle(fontSize: 16)),
            ),
            const SizedBox(height: 16),
            const Text(
              'Analysis could not be completed, but your speech was successfully transcribed.',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _resetForNewRecording();
            },
            child: const Text('Record Again'),
          ),
        ],
      ),
    );
  }

  /// Show loading dialog with message
  void _showLoadingDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        content: Row(
          children: [
            const CircularProgressIndicator(),
            const SizedBox(width: 16),
            Expanded(child: Text(message)),
          ],
        ),
      ),
    );
  }

  /// Show error dialog
  void _showErrorDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  /// Reset state for new listening session
  void _resetForNewRecording() {
    setState(() {
      _transcribedText = '';
      _confidence = '';
      _voiceService.resetTracking();
      _currentVoiceAnalysis = null;
    });
  }

  /// Toggle listening state
  Future<void> _toggleListening() async {
    if (_isListening) {
      await _stopListening();
    } else {
      await _startListening();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Speech Pronunciation Analyzer'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.blue.withOpacity(0.05), Colors.white],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Title and description
                const Text(
                  'Speak Naturally & Get Instant Analysis',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                Text(
                  'Press the microphone, speak clearly in English, '
                  'then get your pronunciation score and detailed feedback.',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey[600],
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 60),

                // Recording button
                GestureDetector(
                  onTap: _toggleListening,
                  child: Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: _isListening
                            ? [Colors.red, Colors.red.shade700]
                            : [Colors.blue, Colors.blue.shade700],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (_isListening ? Colors.red : Colors.blue)
                              .withOpacity(0.3),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Icon(
                      _isListening ? Icons.stop : Icons.mic,
                      size: 50,
                      color: Colors.white,
                    ),
                  ),
                ),

                const SizedBox(height: 30),

                // Real-time voice level indicator (when listening)
                if (_isListening) ...[
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.blue.withOpacity(0.3)),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.volume_up, color: Colors.blue),
                            const SizedBox(width: 8),
                            const Text(
                              'Voice Level',
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.blue,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        LinearProgressIndicator(
                          value:
                              _currentVoiceAnalysis?.averageVolume.clamp(
                                0.0,
                                1.0,
                              ) ??
                              0.0,
                          backgroundColor: Colors.grey.shade300,
                          color:
                              (_currentVoiceAnalysis?.averageVolume ?? 0.0) <
                                  0.3
                              ? Colors.orange
                              : (_currentVoiceAnalysis?.averageVolume ?? 0.0) <
                                    0.7
                              ? Colors.green
                              : Colors.red,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          (_currentVoiceAnalysis?.averageVolume ?? 0.0) < 0.3
                              ? 'Speak louder'
                              : (_currentVoiceAnalysis?.averageVolume ?? 0.0) <
                                    0.7
                              ? 'Perfect volume'
                              : 'Too loud',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                ],

                // Status text
                Text(
                  _isListening
                      ? 'Listening... Tap to stop'
                      : _transcribedText.isNotEmpty
                      ? 'Tap to try again'
                      : 'Tap to start listening',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                    color: _isListening ? Colors.red : Colors.blue,
                  ),
                ),

                // Show current transcription if available
                if (_transcribedText.isNotEmpty && !_isListening) ...[
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.green.withOpacity(0.3)),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.check_circle, color: Colors.green),
                            const SizedBox(width: 8),
                            const Text(
                              'Recognized:',
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.green,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _transcribedText,
                          style: const TextStyle(fontSize: 16),
                          textAlign: TextAlign.center,
                        ),
                        if (_confidence.isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text(
                            'Confidence: $_confidence%',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 60),

                // Configuration warning
                if (!ApiConfig.isGeminiConfigured) ...[
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.orange.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.orange.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.warning, color: Colors.orange),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Gemini AI not configured. Please set up your API key for analysis features.',
                            style: TextStyle(
                              color: Colors.orange[700],
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                const Spacer(),

                // Instructions
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.lightbulb, color: Colors.blue),
                          const SizedBox(width: 8),
                          Text(
                            'Tips for Best Results',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Colors.blue[700],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        '• Speak clearly and at normal pace\n'
                        '• Ensure quiet environment\n'
                        '• Hold phone close to your mouth\n'
                        '• Vary your pitch and tone naturally\n'
                        '• Use confident volume (not too soft/loud)\n'
                        '• Record for 3-10 seconds',
                        style: TextStyle(fontSize: 14, height: 1.4),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
