import 'package:flutter_test/flutter_test.dart';
import 'package:english_analyze/config/api_config.dart';

void main() {
  group('API Configuration Tests', () {
    test('API key configuration status', () {
      // Test if API key is properly configured
      expect(ApiConfig.geminiApiKey, isNotEmpty);

      // Check if it's still the placeholder
      final isConfigured = ApiConfig.isGeminiConfigured;
      print('Gemini API configured: $isConfigured');

      if (!isConfigured) {
        print('Warning: Replace API key in lib/config/api_config.dart');
        print('See GEMINI_SETUP.md for instructions');
      }

      // Test other config values
      expect(ApiConfig.geminiTimeoutSeconds, greaterThan(0));
      expect(ApiConfig.maxRetryAttempts, greaterThan(0));
    });

    test('Feature flags', () {
      expect(ApiConfig.enableGeminiAnalysis, isA<bool>());
      expect(ApiConfig.enableAdvancedFeatures, isA<bool>());
    });
  });
}
